<div id="content" class="app-content">
	<div class="col-xl-12 ui-sortable">
		<div class="panel panel-inverse" data-sortable-id="form-stuff-1" data-init="true">

			<div class="panel-heading ui-sortable-handle">
				<h4 class="panel-title">KELOLA DATA IZIN SAKIT</h4>
				<div class="panel-heading-btn">
					<a href="javascript:;" class="btn btn-xs btn-icon btn-default" data-toggle="panel-expand" data-bs-original-title="" title="" data-tooltip-init="true"><i class="fa fa-expand"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-success" data-toggle="panel-reload"><i class="fa fa-redo"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-warning" data-toggle="panel-collapse"><i class="fa fa-minus"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-danger" data-toggle="panel-remove"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">

				<form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data">
					<thead>
						<table id="data-table-default" class="table  table-bordered table-hover table-td-valign-middle">

							<tr>
								<td>User<?php echo form_error('user_id') ?></td>
								<td>
									<select name="user_id" class="form-control theSelect">
										<option value="">-- Pilih -- </option>
										<?php foreach ($user_data as $key => $data) { ?>
											<?php if ($user_id == $data->user_id) { ?>
												<option value="<?php echo $data->user_id ?>" selected>
													<?php if ($data->level_id == '2') { ?>
														Guru <?= nama_guru($data->user_id) ?>
													<?php } else if ($data->level_id == '3') { ?>
														Pegawai <?= nama_pegawai($data->user_id) ?>
													<?php } else if ($data->level_id == '4') { ?>
														Siswa <?= nama_siswa($data->user_id) ?>
													<?php } ?>
												</option>
											<?php } else { ?>
												<option value="<?php echo $data->user_id ?>">
													<?php if ($data->level_id == '2') { ?>
														Guru <?= nama_guru($data->user_id) ?>
													<?php } else if ($data->level_id == '3') { ?>
														Pegawai <?= nama_pegawai($data->user_id) ?>
													<?php } else if ($data->level_id == '4') { ?>
														Siswa <?= nama_siswa($data->user_id) ?>
													<?php } ?>
												</option>
											<?php } ?>
										<?php } ?>
									</select>
								</td>
							</tr>


							<tr>
								<td width='200'>Tanggal <?php echo form_error('tanggal') ?></td>
								<td>
									<input type="date" class="form-control" name="tanggal" id="tanggal" placeholder="Tanggal" value="<?php echo $tanggal; ?>" />
									<input type="hidden" class="form-control" name="tanggal_lama" id="tanggal_lama" placeholder="Tanggal" value="<?php echo $tanggal_lama; ?>" />
							</td>
							</tr>
							<?php if ($this->uri->segment(2) == 'create' || $this->uri->segment(2) == 'create_action') { ?>
								<tr>
									<td width='200'>Surat Keterangan <?php echo form_error('photo') ?></td>
									<td><input type="file" class="form-control" name="photo" id="photo" placeholder="photo" required="" value="" onchange="return validasiEkstensi()" />
										<!-- <div id="preview"></div> -->
									</td>
								</tr>
							<?php } else { ?>
								<div class="form-group">
									<tr>
										<td width='200'>Surat Keterangan <?php echo form_error('photo') ?></td>
										<td>
											<a href="#modal-dialog" data-bs-toggle="modal">
												<iframe style="width: 80%; height:450px" src="<?php echo base_url(); ?>assets/assets/img/izin/<?= $photo ?>" style="width: 150px;height: 150px;border-radius: 5%;"></iframe></a>
											<input type="hidden" name="photo_lama" value="<?= $photo ?>">
											<p style="color: red">Note :Pilih Surat Keterangan Jika Ingin Merubah photo</p>
											<input type="file" class="form-control" name="photo" id="photo" placeholder="photo" value="" onchange="return validasiEkstensi()" />
											<!-- <div id="preview"></div> -->
										</td>

									</tr>
								</div>
							<?php } ?>

							<tr>
								<td>Keterangan <?php echo form_error('keterangan') ?></td>
								<td><select name="keterangan" class="form-control theSelect" value="<?= $keterangan ?>">
										<option value="">- Pilih -</option>
										<option value="Izin" <?php echo $keterangan == 'Izin' ? 'selected' : 'null' ?>>Izin</option>
										<option value="Sakit" <?php echo $keterangan == 'Sakit' ? 'selected' : 'null' ?>>Sakit</option>
									</select>
								</td>
							</tr>

							<tr>
								<td width='200'>Deskripsi <?php echo form_error('deskripsi') ?></td>
								<td> <textarea class="form-control" rows="3" name="deskripsi" id="deskripsi" placeholder="Deskripsi"><?php echo $deskripsi; ?></textarea></td>
							</tr>
							<tr>
								<td></td>
								<td><input type="hidden" name="izin_sakit_id" value="<?php echo $izin_sakit_id; ?>" />
									<button type="submit" class="btn btn-danger"><i class="fas fa-save"></i> <?php echo $button ?></button>
									<a href="<?php echo site_url('izin_sakit') ?>" class="btn btn-info"><i class="fas fa-undo"></i> Kembali</a>
								</td>
							</tr>
					</thead>
					</table>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
	$(document).ready(function() {
		$(".theSelect").select2();
	})
</script>
<script type="text/javascript">
	function validasiEkstensi() {
		var inputFile = document.getElementById('photo');
		var pathFile = inputFile.value;
		var ekstensiOk = /(\.jpg|\.jpeg|\.png|\.pdf|\.doc|\.docx)$/i;
		if (!ekstensiOk.exec(pathFile)) {
			alert('Silakan upload file yang memiliki ekstensi .jpeg/.jpg/.png');
			inputFile.value = '';
			return false;
		} else {
			// Preview photo
			if (inputFile.files && inputFile.files[0]) {
				var reader = new FileReader();
				reader.onload = function(e) {
					document.getElementById('preview').innerHTML = '<iframe src="' + e.target.result + '" style="height:150px; width:200px"/>';
				};
				reader.readAsDataURL(inputFile.files[0]);
			}
		}
	}
</script>
