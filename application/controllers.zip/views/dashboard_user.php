<div id="content" class="app-content">
	<?php if ($status_pengumuman == 'Aktif') { ?>
		<div class="note note-primary">
			<div class="note-icon"><i class="fa fa-info"></i></div>
			<div class="note-content">
				<h4><b>PENGUMUMAN</b></h4>
				<p><?= $text ?> </p>
			</div>
		</div>
	<?php } ?>
</div>
