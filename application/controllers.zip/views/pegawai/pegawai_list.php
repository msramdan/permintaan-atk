<div class="modal fade" id="modal_import">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Import Data Pegawai</h4>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
			</div>
			<div class="modal-body">
				<div class="form-group mb-3">
					<a href="<?= base_url() ?>assets/downloads/data_pegawai_format.xlsx" class="btn btn-warning"><i class="fas fa-download fa-fw"></i> Unduh Format Import</a>
				</div>
				<div class="form-group mb-3">
					<label class="form-label" for="upload_excel">Upload Import</label>
					<input type="file" class="form-control" name="file_excel" id="file_excel">
				</div>
			</div>
			<div class="modal-footer">
				<a href="javascript:;" class="btn btn-white" data-bs-dismiss="modal">Close</a>
				<button type="button" class="btn btn-warning btn-upload-excel"><i class="ace-icon fa fa-file-import"></i> Upload</button>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="modal_preview_excel">
	<div class="modal-dialog">
		<div class="modal-content">
			<form id="form_insert_data_excel" action="<?= base_url() ?>pegawai/insert_all_from_excel" method="post" enctype="multipart/form-data">
				<div class="modal-header">
					<h4 class="modal-title">Konfirmasi Import</h4>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
				</div>
				<div class="modal-body">
					<div class="table-responsive">
						<table class="table table-bordered">
							<thead>
								<tr>
									<td>NIP</td>
									<td>Nama pegawai</td>
									<td>Jenis Kelamin</td>
									<td>Status pegawai</td>
									<td>Alamat</td>
									<td>No HP</td>
									<td>Tempat Lahir</td>
									<td>Tanggal Lahir</td>
									<td>Password</td>
								</tr>
							</thead>
							<tbody id="preview_excel_wrapper">

							</tbody>
						</table>
					</div>
				</div>
				<div class="modal-footer">
					<a href="javascript:;" class="btn btn-white" data-bs-dismiss="modal">Close</a>
					<button type="submit" class="btn btn-primary btn-submit-import-excel"><i class="ace-icon fa fa-file-import"></i> Import</button>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- #modal-dialog -->
<div class="modal fade" id="modal-dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Photo <span id="cuts"></span></h4>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
			</div>
			<div class="modal-body">
				<img src="" id="photo_pegawai" width="100%" />
			</div>
			<div class="modal-footer">
				<a href="javascript:;" class="btn btn-white" data-bs-dismiss="modal">Close</a>
				<a class="btn btn-primary" id="download" href=""><i class="ace-icon fa fa-download"></i> Download</a>
			</div>
		</div>
	</div>
</div>

<div id="content" class="app-content">
	<h1 class="page-header">KELOLA DATA PEGAWAI</h1>
	<div class="panel panel-inverse">
		<div class="panel-heading">
			<h4 class="panel-title">List Data pegawai </h4>
			<div class="panel-heading-btn">
				<a href="javascript:;" class="btn btn-xs btn-icon btn-default" data-toggle="panel-expand"><i class="fa fa-expand"></i></a>
				<a href="javascript:;" class="btn btn-xs btn-icon btn-success" data-toggle="panel-reload"><i class="fa fa-redo"></i></a>
				<a href="javascript:;" class="btn btn-xs btn-icon btn-warning" data-toggle="panel-collapse"><i class="fa fa-minus"></i></a>
				<a href="javascript:;" class="btn btn-xs btn-icon btn-danger" data-toggle="panel-remove"><i class="fa fa-times"></i></a>
			</div>
		</div>
		<div class="panel-body">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<div class="x_panel">
						<div class="box-body">
							<div class='row'>
								<div class='col-md-9'>
									<div style="padding-bottom: 10px;">
										<?php echo anchor(site_url('pegawai/create'), '<i class="fas fa-plus-square" aria-hidden="true"></i> Tambah Data', 'class="btn btn-danger btn-sm tambah_data"'); ?>
										<div class="btn-group">
											<?php echo anchor(site_url('pegawai/excel'), '<i class="fas fa-file-export" aria-hidden="true"></i> Export', 'class="btn btn-success btn-sm export_data"'); ?>
											<button type="button" class="btn btn-warning btn-sm import_data"><i class="fas fa-file-import" aria-hidden="true"></i> Import</button>
										</div>
										<?php echo anchor(site_url('pegawai/cetak_semua'), '<i class="fa fa-print" aria-hidden="true"></i> Cetak Semua Kartu', 'class="btn btn-white btn-sm "'); ?>
									</div>
								</div>
							</div>
							<div class="box-body" style="overflow-x: scroll; ">
								<table id="data-table-default" class="table table-bordered table-hover table-td-valign-middle text-white">
									<thead>
										<tr>
											<th>No</th>
											<th>Photo</th>
											<th>Nip</th>
											<th>Nama Pegawai</th>
											<th>Jk Kelamin</th>
											<th>Status Pegawai</th>
											<th>Alamat</th>
											<th>No Hp</th>
											<th>Tempat Lahir</th>
											<th>Tanggal Lahir</th>

											<th>Action</th>
										</tr>
									</thead>
									<tbody><?php $no = 1;
											foreach ($pegawai_data as $pegawai) {
											?>
											<tr>
												<td><?= $no++ ?></td>
												<td>
													<a id="view_gambar" href="#modal-dialog" data-bs-toggle="modal" <?php if ($pegawai->photo == '' || $pegawai->photo == null) { ?> data-photo="default.png" <?php } else { ?> data-photo="<?php echo $pegawai->photo ?>" <?php } ?> data-nama_pegawai="<?php echo $pegawai->nama_pegawai ?>">
														<?php if ($pegawai->photo == '' || $pegawai->photo == null) { ?>
															<img src="<?= base_url() ?>assets/assets/img/pegawai/default.png" class="rounded h-30px my-n1 mx-n1" />
														<?php } else { ?>
															<img src="<?= base_url() ?>assets/assets/img/pegawai/<?php echo $pegawai->photo ?>" class="rounded h-30px my-n1 mx-n1" />
														<?php } ?>

													</a>
												</td>

												<td><?php echo $pegawai->nip ?></td>
												<td><?php echo $pegawai->nama_pegawai ?></td>
												<td><?php echo $pegawai->jk_kelamin ?></td>
												<td><?php echo $pegawai->nama_status_pegawai ?></td>
												<td><?php echo $pegawai->alamat ?></td>
												<td><?php echo $pegawai->no_hp ?></td>
												<td><?php echo $pegawai->tempat_lahir ?></td>
												<td><?php echo $pegawai->tanggal_lahir ?></td>
												<td style="text-align:center" width="200px">
													<?php
													echo anchor(site_url('pegawai/cetak/' . encrypt_url($pegawai->pegawai_id)), '<i class="fas fa-print" aria-hidden="true"></i>', 'class="btn btn-white btn-sm read_data"');
													echo '  ';
													echo anchor(site_url('pegawai/update/' . encrypt_url($pegawai->pegawai_id)), '<i class="fas fa-pencil-alt" aria-hidden="true"></i>', 'class="btn btn-primary btn-sm update_data"');
													echo '  ';
													echo anchor(site_url('pegawai/delete/' . encrypt_url($pegawai->pegawai_id)), '<i class="fas fa-trash-alt" aria-hidden="true"></i>', 'class="btn btn-danger btn-sm delete_data" Delete', 'onclick="javasciprt: return confirm(\'Are You Sure ?\')"');
													?>
												</td>
											</tr>
										<?php } ?>
									</tbody>
								</table>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript">
		function upload_excel_preview() {
			$("#modal_import").removeClass("in");
			$(".modal-backdrop").remove();
			$("#modal_import").hide();
			Swal.fire({
				title: 'Loading',
				text: 'Sedang mengupload data',
				type: 'info',
				allowOutsideClick: false,
				showConfirmButton: false
			});
			var formData = new FormData();
			var file = $('#file_excel')[0].files[0];
			formData.append('file_excel', file);
			$.ajax({
				url: '<?php echo site_url('pegawai/preview_excel') ?>',
				type: 'POST',
				data: formData,
				processData: false,
				contentType: false,
				success: function(data) {
					var dt = JSON.parse(data);
					if (dt.status == 'ok') {
						// trigger modal by javascript
						$('#modal_preview_excel').modal('show');
						$('#preview_excel_wrapper').html(dt.data);
						Swal.close()
						if ($('.not-allowed-to-insert-excel').length >= $('#preview_excel_wrapper tr').length) {
							$('.btn-submit-import-excel').hide();
						}
					} else {
						Swal.fire({
							title: 'Error!',
							text: dt.message,
							type: 'error',
							showConfirmButton: true,
							confirmButtonText: 'Close'
						});
					}
				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
					if (XMLHttpRequest.readyState == 4) {
						// HTTP error (can be checked by XMLHttpRequest.status and XMLHttpRequest.statusText)
						Swal.fire({
							title: 'Error',
							text: 'Gagal mengupload data',
							type: 'error',
							allowOutsideClick: false,
							showConfirmButton: true
						});
					} else if (XMLHttpRequest.readyState == 0) {
						Swal.fire({
							title: 'Error',
							text: 'Gagal mengupload data',
							type: 'error',
							allowOutsideClick: false,
							showConfirmButton: true
						});
					} else {

						Swal.fire({
							title: 'Error',
							text: 'Cek koneksi internet',
							type: 'error',
							allowOutsideClick: false,
							showConfirmButton: true
						});
					}
				}
			});
			$('#file_excel').val('');
		}

		$(document).on('click', '.import_data', function() {
			$('#modal_import').modal('show');
		})

		$(document).on('click', '.btn-upload-excel', function() {
			var fileny = $("#file_excel")[0].files.length;
			if (fileny === 0) {
				Swal.fire({
					title: 'Error!',
					text: 'Pilih File terlebih dahulu',
					type: 'error',
					icon: 'error',
					allowOutsideClick: false,
					showConfirmButton: true
				});
			} else {
				upload_excel_preview()
			}
		})
		$(document).on('click', '#view_gambar', function() {
			var nama_pegawai = $(this).data('nama_pegawai');
			var photo = $(this).data('photo');
			$('#modal-dialog #cuts').text(nama_pegawai);
			$('#modal-dialog #photo_pegawai').attr("src", "assets/assets/img/pegawai/" + photo);
			$('#modal-dialog #download').attr("href", "pegawai/download/" + photo);
		})
	</script>
