<div class="modal fade" id="modal_import">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<a style="width: 100%;padding:10px" class="btn btn-warning" href="<?= base_url() ?>assets/downloads/data_kelas_format.xlsx"><i class="fa fa-download"></i> &nbsp;Download Format Import Siswa</a>
			</div>
			<div class="modal-body">
				<div class="form-group mb-3">
					<label class="form-label" for="file_excel">Upload Import</label>
					<input type="file" class="form-control" name="file_excel" id="file_excel">
				</div>
				<div class="form-group mb-3">
					<label class="form-label" for="upload_excel">Pilih Kelas</label>
					<select class="form-control" id="kelas">
						<option style='color:black' value="">-- Pilih --</option>
						<?php
						$datakelas = $this->db->get('kelas')->result();
						foreach ($datakelas as $kelas) {
							echo "<option style='color:black' value='$kelas->kelas_id'>$kelas->nama_kelas</option>";
						}
						?>
					</select>
				</div>
			</div>
			<div class="modal-footer">
				<a href="javascript:;" class="btn btn-white" data-bs-dismiss="modal">Close</a>
				<button type="button" class="btn btn-warning btn-upload-excel"><i class="ace-icon fa fa-file-import"></i> Upload</button>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="modal_preview_excel">
	<div class="modal-dialog">
		<div class="modal-content">
			<form id="form_insert_data_excel" action="<?= base_url() ?>siswa/insert_all_from_excel" method="post" enctype="multipart/form-data">
				<div class="modal-header">
					<h4 class="modal-title">Konfirmasi Import</h4>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
				</div>
				<div class="modal-body">
					<div class="table-responsive">
						<table class="table table-bordered">
							<thead>
								<tr>
									<td>NISN</td>
									<td>Nama Siswa</td>
									<td>Jenis Kelamin</td>
									<td>Kelas</td>
									<td>Alamat</td>
									<td>Tempat Lahir</td>
									<td>Tanggal Lahir</td>
									<td>Nama Wali Siswa</td>
									<td>No HP Wali Siswa</td>
									<td>Password</td>
								</tr>
							</thead>
							<tbody id="preview_excel_wrapper">

							</tbody>
						</table>
					</div>
				</div>
				<div class="modal-footer">
					<a href="javascript:;" class="btn btn-white" data-bs-dismiss="modal">Close</a>
					<button type="submit" class="btn btn-primary btn-submit-import-excel"><i class="ace-icon fa fa-file-import"></i> Import</button>
				</div>
			</form>
		</div>
	</div>
</div>

<div id="content" class="app-content">
	<h1 class="page-header">KELOLA DATA SISWA</h1>
	<div class="panel panel-inverse">
		<div class="panel-heading">
			<h4 class="panel-title">List Data siswa </h4>
			<div class="panel-heading-btn">
				<a href="javascript:;" class="btn btn-xs btn-icon btn-default" data-toggle="panel-expand"><i class="fa fa-expand"></i></a>
				s <a href="javascript:;" class="btn btn-xs btn-icon btn-success" data-toggle="panel-reload"><i class="fa fa-redo"></i></a>
				<a href="javascript:;" class="btn btn-xs btn-icon btn-warning" data-toggle="panel-collapse"><i class="fa fa-minus"></i></a>
				<a href="javascript:;" class="btn btn-xs btn-icon btn-danger" data-toggle="panel-remove"><i class="fa fa-times"></i></a>
			</div>
		</div>
		<div class="panel-body">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<div class="x_panel">
						<div class="box-body">
							<div class='row'>
								<div class='col-md-9'>
									<div style="padding-bottom: 10px;">
										<div class="btn-group">
											<button type="button" class="btn btn-warning btn-sm import_data"><i class="fas fa-file-import" aria-hidden="true"></i> Import</button>

										</div>
									</div>
								</div>
							</div>
							<div class="box-body" style="overflow-x: scroll; ">
								<table id="data-table-default" class="table table-bordered table-hover table-td-valign-middle text-white">
									<thead>
										<tr>
											<th style="width: 5%;">No</th>
											<th>Nama Kelas</th>
											<th>Daftar Siswa</th>
										</tr>
									</thead>
									<tbody><?php $no = 1;
											foreach ($kelas_data as $kelas) {
											?>
											<tr>
												<td><?= $no++ ?></td>
												<td><?php echo $kelas->nama_kelas ?></td>
												<td><a href="<?= base_url() ?>siswa/daftar_siswa?kelas_id=<?= $kelas->kelas_id ?>" class="btn btn-success btn-sm read_data"><i class="fas fa-eye" aria-hidden="true"></i>
														<?php $query = $this->db->query("SELECT * FROM siswa where kelas_id='$kelas->kelas_id'");
														echo $query->num_rows(); ?>
														Daftar Siswa</a></td>
											</tr>
										<?php } ?>
									</tbody>
								</table>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script>
		function upload_excel_preview() {
			$("#modal_import").removeClass("in");
			$(".modal-backdrop").remove();
			$("#modal_import").hide();
			Swal.fire({
				title: 'Loading',
				text: 'Sedang mengupload data',
				type: 'info',
				allowOutsideClick: false,
				showConfirmButton: false
			});
			var formData = new FormData();
			var file = $('#file_excel')[0].files[0];
			var kelas = $('#kelas').val();
			formData.append('file_excel', file);
			formData.append('kelas', kelas);
			$.ajax({
				url: '<?php echo site_url('siswa/preview_excel') ?>',
				type: 'POST',
				data: formData,
				processData: false,
				contentType: false,
				success: function(data) {
					var dt = JSON.parse(data);
					if (dt.status == 'ok') {
						// trigger modal by javascript
						$('#modal_preview_excel').modal('show');
						$('#preview_excel_wrapper').html(dt.data);
						Swal.close()
						console.log($('.not-allowed-to-insert-excel').length)
						if ($('.not-allowed-to-insert-excel').length >= $('#preview_excel_wrapper tr').length) {
							$('.btn-submit-import-excel').hide();
						}
					} else {
						Swal.fire({
							title: 'Error!',
							text: dt.message,
							type: 'error',
							showConfirmButton: true,
							confirmButtonText: 'Close'
						});
					}
				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
					if (XMLHttpRequest.readyState == 4) {
						// HTTP error (can be checked by XMLHttpRequest.status and XMLHttpRequest.statusText)
						Swal.fire({
							title: 'Error',
							text: 'Gagal mengupload data',
							type: 'error',
							allowOutsideClick: false,
							showConfirmButton: true
						});
					} else if (XMLHttpRequest.readyState == 0) {
						Swal.fire({
							title: 'Error',
							text: 'Gagal mengupload data',
							type: 'error',
							allowOutsideClick: false,
							showConfirmButton: true
						});
					} else {

						Swal.fire({
							title: 'Error',
							text: 'Cek koneksi internet',
							type: 'error',
							allowOutsideClick: false,
							showConfirmButton: true
						});
					}
				}
			});
			$('#file_excel').val('');
		}

		$(document).on('click', '.import_data', function() {
			$('#modal_import').modal('show');
		})

		$(document).on('click', '.btn-upload-excel', function() {
			var fileny = $("#file_excel")[0].files.length;
			var kelas_id = $('#kelas').val();
			console.log(kelas_id)
			if (fileny === 0) {
				Swal.fire({
					title: 'Error!',
					text: 'Pilih File terlebih dahulu',
					type: 'error',
					icon: 'error',
					allowOutsideClick: false,
					showConfirmButton: true
				});
			} else if (kelas_id == '' || !kelas_id) {
				Swal.fire({
					title: 'Error!',
					text: 'Pilih kelas terlebih dahulu',
					type: 'error',
					icon: 'error',
					allowOutsideClick: false,
					showConfirmButton: true
				});
			} else {
				upload_excel_preview()
			}
		})
	</script>
