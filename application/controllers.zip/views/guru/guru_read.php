<div id="content" class="app-content">
	<div class="col-xl-12 ui-sortable">
		<div class="panel panel-inverse" data-sortable-id="form-stuff-1" data-init="true">
			<div class="panel-heading ui-sortable-handle">
				<h4 class="panel-title">Guru Read</h4>
				<div class="panel-heading-btn">
					<a href="javascript:;" class="btn btn-xs btn-icon btn-default" data-toggle="panel-expand" data-bs-original-title="" title="" data-tooltip-init="true"><i class="fa fa-expand"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-success" data-toggle="panel-reload"><i class="fa fa-redo"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-warning" data-toggle="panel-collapse"><i class="fa fa-minus"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-danger" data-toggle="panel-remove"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">
				<table id="data-table-default" class="table table-hover table-bordered table-td-valign-middle">
					<tr>
						<td>Nip</td>
						<td><?php echo $nip; ?></td>
					</tr>
					<tr>
						<td>Nama Guru</td>
						<td><?php echo $nama_guru; ?></td>
					</tr>
					<tr>
						<td>Jk Kelamin</td>
						<td><?php echo $jk_kelamin; ?></td>
					</tr>
					<tr>
						<td>Status Guru</td>
						<td><?php echo $status_guru_id; ?></td>
					</tr>
					<tr>
						<td>Alamat</td>
						<td><?php echo $alamat; ?></td>
					</tr>
					<tr>
						<td>No Hp</td>
						<td><?php echo $no_hp; ?></td>
					</tr>
					<tr>
						<td>Tempat Lahir</td>
						<td><?php echo $tempat_lahir; ?></td>
					</tr>
					<tr>
						<td>Tanggal Lahir</td>
						<td><?php echo $tanggal_lahir; ?></td>
					</tr>
					<tr>
						<td>Photo</td>
						<td><?php echo $photo; ?></td>
					</tr>
					<tr>
						<td></td>
						<td><a href="<?php echo site_url('guru') ?>" class="btn btn-default">Cancel</a></td>
					</tr>
				</table>
			</div>
		</div>
	</div>
</div>
