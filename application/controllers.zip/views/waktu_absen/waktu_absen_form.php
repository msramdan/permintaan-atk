<div id="content" class="app-content">
	<div class="col-xl-12 ui-sortable">
		<div class="panel panel-inverse" data-sortable-id="form-stuff-1" style="" data-init="true">

			<div class="panel-heading ui-sortable-handle">
				<h4 class="panel-title">KELOLA DATA WAKTU_ABSEN</h4>
				<div class="panel-heading-btn">
					<a href="javascript:;" class="btn btn-xs btn-icon btn-default" data-toggle="panel-expand" data-bs-original-title="" title="" data-tooltip-init="true"><i class="fa fa-expand"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-success" data-toggle="panel-reload"><i class="fa fa-redo"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-warning" data-toggle="panel-collapse"><i class="fa fa-minus"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-danger" data-toggle="panel-remove"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">

				<form action="<?php echo $action; ?>" method="post">
					<thead>
						<table id="data-table-default" class="table  table-bordered table-hover table-td-valign-middle">
							<tr>
								<td width='200'>Nama Hari <?php echo form_error('nama_hari') ?></td>
								<td><input type="text" class="form-control" name="nama_hari" id="nama_hari" placeholder="Nama Hari" value="<?php echo $nama_hari; ?>" /></td>
							</tr>
							<tr>
								<td width='200'>Jam Masuk Guru <?php echo form_error('jam_masuk_guru') ?></td>
								<td><input type="time" class="form-control" name="jam_masuk_guru" id="jam_masuk_guru" placeholder="Jam Masuk Guru" value="<?php echo $jam_masuk_guru; ?>" /></td>
							</tr>
							<tr>
								<td width='200'>Absen Terlambat Guru <?php echo form_error('absen_terlambat_guru') ?></td>
								<td><input type="bumber" min="0" class="form-control" name="absen_terlambat_guru" id="absen_terlambat_guru" placeholder="Absen Terlambat Guru" value="<?php echo $absen_terlambat_guru; ?>" /></td>
							</tr>
							<tr>
								<td width='200'>Jam Masuk Siswa <?php echo form_error('jam_masuk_siswa') ?></td>
								<td><input type="time" class="form-control" name="jam_masuk_siswa" id="jam_masuk_siswa" placeholder="Jam Masuk Siswa" value="<?php echo $jam_masuk_siswa; ?>" /></td>
							</tr>
							<tr>
								<td width='200'>Absen Terlambat Siswa <?php echo form_error('absen_terlambat_siswa') ?></td>
								<td><input type="number" min="0" class="form-control" name="absen_terlambat_siswa" id="absen_terlambat_siswa" placeholder="Absen Terlambat Siswa" value="<?php echo $absen_terlambat_siswa; ?>" /></td>
							</tr>
							<tr>
								<td width='200'>Jam Pulang Guru <?php echo form_error('jam_pulang_guru') ?></td>
								<td><input type="time" class="form-control" name="jam_pulang_guru" id="jam_pulang_guru" placeholder="Jam Pulang Guru" value="<?php echo $jam_pulang_guru; ?>" /></td>
							</tr>
							<tr>
								<td width='200'>Jam Pulang Siswa <?php echo form_error('jam_pulang_siswa') ?></td>
								<td><input type="time" class="form-control" name="jam_pulang_siswa" id="jam_pulang_siswa" placeholder="Jam Pulang Siswa" value="<?php echo $jam_pulang_siswa; ?>" /></td>
							</tr>
							<tr>
								<td></td>
								<td><input type="hidden" name="waktu_absen" value="<?php echo $waktu_absen; ?>" />
									<button type="submit" class="btn btn-danger"><i class="fas fa-save"></i> <?php echo $button ?></button>
									<a href="<?php echo site_url('waktu_absen') ?>" class="btn btn-info"><i class="fas fa-undo"></i> Kembali</a>
								</td>
							</tr>
					</thead>
					</table>
				</form>
			</div>
		</div>
	</div>
</div>
