<div id="content" class="app-content">
	<h1 class="page-header">KELOLA DATA WAKTU_ABSEN</h1>
	<div class="panel panel-inverse">
		<div class="panel-heading">
			<h4 class="panel-title">List Data waktu_absen </h4>
			<div class="panel-heading-btn">
				<a href="javascript:;" class="btn btn-xs btn-icon btn-default" data-toggle="panel-expand"><i class="fa fa-expand"></i></a>
				<a href="javascript:;" class="btn btn-xs btn-icon btn-success" data-toggle="panel-reload"><i class="fa fa-redo"></i></a>
				<a href="javascript:;" class="btn btn-xs btn-icon btn-warning" data-toggle="panel-collapse"><i class="fa fa-minus"></i></a>
				<a href="javascript:;" class="btn btn-xs btn-icon btn-danger" data-toggle="panel-remove"><i class="fa fa-times"></i></a>
			</div>
		</div>
		<div class="panel-body">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<div class="x_panel">
						<div class="box-body">
							<div class='row'>
								<div class='col-md-9'>
									<div style="padding-bottom: 10px;">
									
										<!-- <?php echo anchor(site_url('waktu_absen/excel'), '<i class="far fa-file-excel" aria-hidden="true"></i> Export Ms Excel', 'class="btn btn-success btn-sm export_data"'); ?> -->
									</div>
								</div>
							</div>
							<div class="box-body" style="overflow-x: scroll; ">
								<table id="data-table-default" class="table table-bordered table-hover table-td-valign-middle text-white">
									<thead>
										<tr>
											<th>No</th>
											<th>Nama Hari</th>
											<th>Jam Masuk Guru</th>
											<th>Absen Terlambat Guru <span style="color: red;">Berapa menit dari jam masuk</span> </th>
											<th>Jam Masuk Siswa</th>
											<th>Absen Terlambat Siswa  <span style="color: red;">Berapa menit dari jam masuk</span></th>
											<th>Jam Pulang Guru</th>
											<th>Jam Pulang Siswa</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody><?php $no = 1;
											foreach ($waktu_absen_data as $waktu_absen) {
											?>
											<tr>
												<td><?= $no++ ?></td>
												<td><?php echo $waktu_absen->nama_hari ?></td>
												<td><?php echo $waktu_absen->jam_masuk_guru ?></td>
												<td><?php echo $waktu_absen->absen_terlambat_guru ?></td>
												<td><?php echo $waktu_absen->jam_masuk_siswa ?></td>
												<td><?php echo $waktu_absen->absen_terlambat_siswa ?></td>
												<td><?php echo $waktu_absen->jam_pulang_guru ?></td>
												<td><?php echo $waktu_absen->jam_pulang_siswa ?></td>
												<td style="text-align:center">
													<?php

													echo anchor(site_url('waktu_absen/update/' . encrypt_url($waktu_absen->waktu_absen)), '<i class="fas fa-pencil-alt" aria-hidden="true"></i>', 'class="btn btn-primary btn-sm update_data"');
													?>
												</td>
											</tr>
										<?php } ?>
									</tbody>
								</table>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
