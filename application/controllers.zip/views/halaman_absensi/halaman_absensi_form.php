<div id="content" class="app-content">
	<div class="col-xl-12 ui-sortable">
		<div class="panel panel-inverse" data-sortable-id="form-stuff-1" style="" data-init="true">

			<div class="panel-heading ui-sortable-handle">
				<h4 class="panel-title">KELOLA DATA HALAMAN_ABSENSI</h4>
				<div class="panel-heading-btn">
					<a href="javascript:;" class="btn btn-xs btn-icon btn-default" data-toggle="panel-expand" data-bs-original-title="" title="" data-tooltip-init="true"><i class="fa fa-expand"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-success" data-toggle="panel-reload"><i class="fa fa-redo"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-warning" data-toggle="panel-collapse"><i class="fa fa-minus"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-danger" data-toggle="panel-remove"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">

				<form action="<?php echo $action; ?>" method="post">
					<thead>
						<table id="data-table-default" class="table  table-bordered table-hover table-td-valign-middle">
							<tr>
								<td>Is Aktif <?php echo form_error('is_aktif') ?></td>
								<td><select name="is_aktif" class="form-control theSelect" value="<?= $is_aktif ?>">
										<option value="">- Pilih -</option>
										<option value="Aktif" <?php echo $is_aktif == 'Aktif' ? 'selected' : 'null' ?>>Aktif</option>
										<option value="Non Aktif" <?php echo $is_aktif == 'Non Aktif' ? 'selected' : 'null' ?>>Non Aktif</option>
									</select>
								</td>
							</tr>
							<tr>
								<td width='200'>Password Lock Screen<?php echo form_error('password_lock_screen') ?></td>
								<td><input type="password_lock_screen" class="form-control" name="password_lock_screen" id="password_lock_screen" placeholder="Password lock screen" value="" />
									<small style="color: red">(Biarkan kosong jika tidak diganti)</small>
								</td>
							</tr>
							<tr>
								<td></td>
								<td><input type="hidden" name="halaman_absensi_id" value="<?php echo $halaman_absensi_id; ?>" />
									<button type="submit" class="btn btn-danger"><i class="fas fa-save"></i> <?php echo $button ?></button>
								</td>
							</tr>
					</thead>
					</table>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
	$(document).ready(function() {
		$(".theSelect").select2();
	})
</script>
