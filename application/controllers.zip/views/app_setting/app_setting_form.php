<div id="content" class="app-content">
	<div class="col-xl-12 ui-sortable">
		<div class="panel panel-inverse" data-sortable-id="form-stuff-1" style="" data-init="true">

			<div class="panel-heading ui-sortable-handle">
				<h4 class="panel-title">KELOLA DATA APP_SETTING</h4>
				<div class="panel-heading-btn">
					<a href="javascript:;" class="btn btn-xs btn-icon btn-default" data-toggle="panel-expand" data-bs-original-title="" title="" data-tooltip-init="true"><i class="fa fa-expand"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-success" data-toggle="panel-reload"><i class="fa fa-redo"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-warning" data-toggle="panel-collapse"><i class="fa fa-minus"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-danger" data-toggle="panel-remove"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">

				<form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data">
					<thead>
						<table id="data-table-default" class="table  table-bordered table-hover table-td-valign-middle">
							<tr>
								<td width='200'>Nama Aplikasi <?php echo form_error('nama_aplikasi') ?></td>
								<td><input type="text" class="form-control" name="nama_aplikasi" id="nama_aplikasi" placeholder="Nama Aplikasi" value="<?php echo $nama_aplikasi; ?>" /></td>
							</tr>
							<tr>
								<td width='200'>Nama Sekolah <?php echo form_error('nama_sekolah') ?></td>
								<td><input type="text" class="form-control" name="nama_sekolah" id="nama_sekolah" placeholder="Nama Sekolah" value="<?php echo $nama_sekolah; ?>" /></td>
							</tr>

							<tr>
								<td width='200'>Alamat Sekolah <?php echo form_error('alamat_sekolah') ?></td>
								<td> <textarea class="form-control" rows="3" name="alamat_sekolah" id="alamat_sekolah" placeholder="Alamat Sekolah"><?php echo $alamat_sekolah; ?></textarea></td>
							</tr>

							<tr>
								<td width='200'>Kepala Sekolah <?php echo form_error('kepala_sekolah') ?></td>
								<td><input type="text" class="form-control" name="kepala_sekolah" id="kepala_sekolah" placeholder="Kepala Sekolah" value="<?php echo $kepala_sekolah; ?>" /></td>
							</tr>
							<div class="form-group">
								<tr>
									<td>Logo Sekolah <?php echo form_error('logo_sekolah') ?></td>
									<td>
										<a href="" data-bs-toggle="modal"><img src="<?php echo base_url(); ?>assets/assets/img/logo/<?= $logo_sekolah ?>" style="width: 150px;height: 150px;border-radius: 5%;"></img></a>
										<input type="hidden" name="logo_sekolah_lama" value="<?= $logo_sekolah ?>">
										<p style="color: red">Note :Pilih Logo Sekolah Jika Ingin Merubahnya</p>
										<input type="file" class="form-control" name="logo_sekolah" id="logo_sekolah" placeholder="logo_sekolah" value="" onchange="return validasiEkstensi()" />
									</td>
								</tr>
							</div>
							<tr>
								<td>Wa Blast <?php echo form_error('wa_blast') ?></td>
								<td><select name="wa_blast" class="form-control theSelect" value="<?= $wa_blast ?>">
										<option style="color: black;" value="">-- Pilih --</option>
										<option style="color: black;" value="Aktif" <?php echo $wa_blast == 'Aktif' ? 'selected' : 'null' ?>>Aktif</option>
										<option style="color: black;" value="Non Aktif" <?php echo $wa_blast == 'Non Aktif' ? 'selected' : 'null' ?>>Non Aktif</option>
									</select>
								</td>
							</tr>
							<tr>
								<td></td>
								<td><input type="hidden" name="id" value="<?php echo $id; ?>" />
									<button type="submit" class="btn btn-danger"><i class="fas fa-save"></i> <?php echo $button ?></button>
									<!-- <a href="<?php echo site_url('app_setting') ?>" class="btn btn-info"><i class="fas fa-undo"></i> Kembali</a> -->
								</td>
							</tr>
					</thead>
					</table>
				</form>
			</div>
		</div>
	</div>
</div>
