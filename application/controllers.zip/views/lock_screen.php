<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<title>Color Admin | Coming Soon Page</title>
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />

	<link href="<?= base_url() ?>assets/assets/css/vendor.min.css" rel="stylesheet" />
	<link href="<?= base_url() ?>assets/assets/css/transparent/app.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
</head>

<body class='pace-top'>

	<div class="app-cover"></div>
	<div id="app" class="app">

		<div class="coming-soon">
			<div class="coming-soon-header">
				<div class="bg-cover"></div>
			</div>
			<div class="coming-soon-content">

				<img src="<?php echo base_url(); ?>assets/assets/img/logo/<?= $sett_apps->logo_sekolah ?>" style="width: 150px;height: 150px;border-radius: 5%;"></img>
				<div class="brand">
					<?= $sett_apps->nama_aplikasi ?>
				</div>
				<?php if ($this->session->flashdata('message')) : ?>
				<?php endif; ?>

				<div class="flash-data2" data-flashdata2="<?= $this->session->flashdata('error'); ?>"></div>
				<?php if ($this->session->flashdata('error')) : ?>
				<?php endif; ?>
				<div class="desc">
					Silahkan masukan password untuk membuka halaman absensi.
					<br>
					<br>
					<form action="<?= base_url() ?>absensi/un_lock" method="POST">
						<div class="input-group input-group-lg mx-auto mb-2">
							<span class="input-group-text border-0"><i class="fas fa-lock-open"></i></span>
							<input type="password" name="password" class="form-control fs-13px border-0 shadow-none" placeholder="Password" />
							<button type="submit" name="un_lock" class="btn fs-13px btn-primary">Submit</button>
						</div>
					</form>

				</div>

			</div>
			<a href="javascript:;" class="btn btn-icon btn-circle btn-success btn-scroll-to-top" data-toggle="scroll-to-top"><i class="fa fa-angle-up"></i></a>
		</div>
		<script src="<?= base_url() ?>assets/assets/js/vendor.min.js" type="a18806d67f21ea51b29e0428-text/javascript"></script>
		<script src="<?= base_url() ?>assets/assets/js/app.min.js" type="a18806d67f21ea51b29e0428-text/javascript"></script>
		<script src="<?= base_url() ?>assets/assets/js/demo/coming-soon.demo.js" type="a18806d67f21ea51b29e0428-text/javascript"></script>
		<script src="<?= base_url() ?>assets/assets/js/rocket-loader.min.js" data-cf-settings="beba54df5f87d24c2458d535-|49" defer=""></script>
		<script type="text/javascript" src="<?php echo base_url(); ?>assets/assets/js/sweetalert.min.js"></script>
		<script type="text/javascript" src="<?php echo base_url(); ?>assets/assets/js/sweetalert.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script> <!-- untuk sweet alret -->
		<script src="<?php echo base_url(); ?>assets/assets/js/dataflash.js"></script>
</body>

</html>
