<div id="content" class="app-content">
	<div class="col-xl-12 ui-sortable">
		<div class="panel panel-inverse" data-sortable-id="form-stuff-1" style="" data-init="true">

			<div class="panel-heading ui-sortable-handle">
				<h4 class="panel-title">KONFIGURASI TAMBAHAN</h4>
				<div class="panel-heading-btn">
					<a href="javascript:;" class="btn btn-xs btn-icon btn-default" data-toggle="panel-expand" data-bs-original-title="" title="" data-tooltip-init="true"><i class="fa fa-expand"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-success" data-toggle="panel-reload"><i class="fa fa-redo"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-warning" data-toggle="panel-collapse"><i class="fa fa-minus"></i></a>
					<a href="javascript:;" class="btn btn-xs btn-icon btn-danger" data-toggle="panel-remove"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">
                <thead>
                    <table id="data-table-default" class="table  table-bordered table-hover table-td-valign-middle">
                        <?php
                            foreach ($konfigurasi_tambahan_data as $konfigurasi_tambahan) {
                                ?>
                                    <tr>
                                        <td><i class="fa fa-music"></i>
                                            <?= $konfigurasi_tambahan->config_title_long ?>
                                            <p style="color: red;">*wajib upload .wav</p>
                                        </td>
                                        <td>
                                            <?php
                                            if($konfigurasi_tambahan->config_type == 'FILE_UPLOAD'){
                                                ?>
                                                    <div class="input-group mb-2">
                                                        <input type="file" accept=".wav" name="<?= $konfigurasi_tambahan->config_name ?>" class="form-control type_sound" value="" onchange="return validasiEkstensi()" />
                                                        <button class="btn btn-success btn-save btn-sm" id="<?= $konfigurasi_tambahan->id_config ?>" data-type="<?= $konfigurasi_tambahan->config_type ?>"><i class="fas fa-save fa-fw"></i></button>
                                                    </div>
                                                        <p class="mb-2">Digunakan: <b><?= $konfigurasi_tambahan->name_sound == NULL ? 'Tidak ada' : $konfigurasi_tambahan->name_sound ?> <span><button play="<?= $konfigurasi_tambahan->value ?>" class="btn btn-sm btn-indigo btn-play-current-configurated" style="font-size: 6px; padding: 4px;"><i class="fas fa-play"></i></button></span></b></p>
                                                <?php
                                            }
                                            ?>                                                
                                        </td>
                                    </tr>
                                <?php
                            }
                        ?>
                    </thead>
                </table>
			</div>
		</div>
	</div>
</div>
<script>
    $(document).ready(function() {

        var audio = new Audio();

        $(document).on('click', '.btn-play-current-configurated', function(){
            audio = new Audio('<?= base_url('assets/audio/') ?>'+$(this).attr('play'));

            
            audio.play();
            $(this).html('<i class="fas fa-stop"></i>');
            $(this).attr('class', 'btn btn-sm btn-danger btn-stop-current-configurated');
            
            var thisel = $(this)

            audio.addEventListener("ended", function(){
                audio.currentTime = 0;
                console.log("ended");
                thisel.html('<i class="fas fa-play"></i>');
                thisel.attr('class', 'btn btn-sm btn-indigo btn-play-current-configurated');
            });
            
        })

        $(document).on('click', '.btn-stop-current-configurated', function(){
            audio.pause();
            audio.currentTime = 0;
            $(this).html('<i class="fas fa-play"></i>');
            $(this).attr('class', 'btn btn-sm btn-indigo btn-play-current-configurated');
        })

        $(document).on('click','.btn-save', function(){
            
            var id_config = $(this).attr('id');
            var type = $(this).attr('data-type');
            var file = $(this).parents('tr').find('input[type="file"]').prop('files')[0];

            var form_data = new FormData();
            form_data.append('file', file);
            form_data.append('id_config', id_config);
            form_data.append('type', type);

            swal.fire({
                title: "Uploading...",
                text: "Please wait a moment",
                allowOutsideClick: false,
                onOpen: () => {
                    swal.showLoading()
                }
            });
                
            $.ajax({
                url: "<?php echo base_url() ?>Konfigurasi_tambahan/update_action",
                type: 'POST',
                cache: false,
                contentType: false,
                processData: false,
                data: form_data,
                success: function(resp){
                    var data = JSON.parse(resp);
                    if(data.status){
                        swal.fire({
                            title: "Success!",
                            text: "File berhasil diupload",
                            type: "success",
                            icon: 'success',
                            timer: 1000,
                        }).then(function(){
                            location.reload();
                        });
                    }else{
                        alert(data.message);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown){
                    alert('Error, Please try again!');
                    // close swal
                    swal.close();
                }
            });
        })

    });
</script>

<script type="text/javascript">
    // validate .type_sound file is .wav then empty the input file
    function validasiEkstensi() {
        var input, file;
        input = $('.type_sound').get(0);
        file = input.files[0];
        if (file.type.match('audio/wav')) {
            return true;
        } else {
            alert('File harus .wav');
            input.value = '';
            return false;
        }
    }

    $(document).on('change','.type_sound', function(){
        validasiEkstensi()
    })
</script>
