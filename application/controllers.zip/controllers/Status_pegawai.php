<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Status_pegawai extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
		check_admin();
        $this->load->model('Status_pegawai_model');
		$this->load->model('App_setting_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $status_pegawai = $this->Status_pegawai_model->get_all();
        $data = array(
            'status_pegawai_data' => $status_pegawai,
			'sett_apps' =>$this->App_setting_model->get_by_id(1),
        );
        $this->template->load('template','status_pegawai/status_pegawai_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Status_pegawai_model->get_by_id(decrypt_url($id));
        if ($row) {
            $data = array(
		'status_pegawai_id' => $row->status_pegawai_id,
		'nama_status_pegawai' => $row->nama_status_pegawai,
		'sett_apps' =>$this->App_setting_model->get_by_id(1),
	    );
            $this->template->load('template','status_pegawai/status_pegawai_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('status_pegawai'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('status_pegawai/create_action'),
			'sett_apps' =>$this->App_setting_model->get_by_id(1),
	    'status_pegawai_id' => set_value('status_pegawai_id'),
	    'nama_status_pegawai' => set_value('nama_status_pegawai'),
	);
        $this->template->load('template','status_pegawai/status_pegawai_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'nama_status_pegawai' => $this->input->post('nama_status_pegawai',TRUE),
	    );

            $this->Status_pegawai_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('status_pegawai'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Status_pegawai_model->get_by_id(decrypt_url($id));

        if ($row) {
            $data = array(
                'button' => 'Update',
				'sett_apps' =>$this->App_setting_model->get_by_id(1),
                'action' => site_url('status_pegawai/update_action'),
		'status_pegawai_id' => set_value('status_pegawai_id', $row->status_pegawai_id),
		'nama_status_pegawai' => set_value('nama_status_pegawai', $row->nama_status_pegawai),
	    );
            $this->template->load('template','status_pegawai/status_pegawai_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('status_pegawai'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
			$this->update(encrypt_url($this->input->post('status_pegawai_id')));
        } else {
            $data = array(
		'nama_status_pegawai' => $this->input->post('nama_status_pegawai',TRUE),
	    );

            $this->Status_pegawai_model->update($this->input->post('status_pegawai_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('status_pegawai'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Status_pegawai_model->get_by_id(decrypt_url($id));

        if ($row) {
            $this->Status_pegawai_model->delete(decrypt_url($id));
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('status_pegawai'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('status_pegawai'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('nama_status_pegawai', 'nama status pegawai', 'trim|required');

	$this->form_validation->set_rules('status_pegawai_id', 'status_pegawai_id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "status_pegawai.xls";
        $judul = "status_pegawai";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Nama Status Pegawai");

	foreach ($this->Status_pegawai_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nama_status_pegawai);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

}

/* End of file Status_pegawai.php */
/* Location: ./application/controllers/Status_pegawai.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2022-01-10 16:15:17 */
/* http://harviacode.com */
