<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Siswa extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		is_login();
		$this->load->model('App_setting_model');
		$this->load->model('Kelas_model');
		$this->load->model('Siswa_model');
		$this->load->model('User_model');
		$this->load->library('form_validation');
	}

	public function index()
	{
		check_admin();
		$kelas = $this->Kelas_model->get_all();
		$data = array(
			'kelas_data' => $kelas,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('template', 'siswa/siswa_list', $data);
	}

	public function daftar_siswa()
	{
		check_admin();
		$kelas_id = $_GET['kelas_id'];
		$data = array(
			'siswa_data' => $this->Siswa_model->get_all($kelas_id),
			'kelas_id' => $kelas_id,
			'kelas' => $this->Kelas_model->get_all(),
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('template', 'siswa/daftar_siswa', $data);
	}

	public function read($id)
	{
		check_admin();
		$row = $this->Siswa_model->get_by_id(decrypt_url($id));
		if ($row) {
			$data = array(
				'siswa_id' => $row->siswa_id,
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'nisn' => $row->nisn,
				'nama_siswa' => $row->nama_siswa,
				'jk_kelamin' => $row->jk_kelamin,
				'kelas_id' => $row->kelas_id,
				'alamat' => $row->alamat,
				'tempat_lahir' => $row->tempat_lahir,
				'tanggal_lahir' => $row->tanggal_lahir,
				'photo' => $row->photo,
				'nama_wali_siswa' => $row->nama_wali_siswa,
				'no_hp_wali_siswa' => $row->no_hp_wali_siswa,

			);
			$this->template->load('template', 'siswa/siswa_read', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('siswa'));
		}
	}

	public function create()
	{
		check_admin();
		$data = array(
			'button' => 'Create',
			'kelas' => $this->Kelas_model->get_all(),
			'password' => set_value('password'),
			'nisn_lama' => set_value('nisn'),
			'action' => site_url('siswa/create_action'),
			'siswa_id' => set_value('siswa_id'),
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'nisn' => set_value('nisn'),
			'nama_siswa' => set_value('nama_siswa'),
			'jk_kelamin' => set_value('jk_kelamin'),
			'kelas_id' => set_value('kelas_id'),
			'alamat' => set_value('alamat'),
			'tempat_lahir' => set_value('tempat_lahir'),
			'tanggal_lahir' => set_value('tanggal_lahir'),
			'photo' => set_value('photo'),
			'nama_wali_siswa' => set_value('nama_wali_siswa'),
			'no_hp_wali_siswa' => set_value('no_hp_wali_siswa'),
		);
		$this->template->load('template', 'siswa/siswa_form', $data);
	}

	public function create_action()
	{
		check_admin();
		$this->_rules(null, null, null);

		if ($this->form_validation->run() == FALSE) {
			$this->create();
		} else {
			$data2 = array(
				'password' => sha1($this->input->post('password', TRUE)),
				'username' => $this->input->post('nisn', TRUE),
				'level_id' => 4
			);
			$this->db->insert('user', $data2);

			if ($this->db->affected_rows() > 0) {

				$this->load->library('ciqrcode'); //pemanggilan library QR CODE

				$config['cacheable']    = true; //boolean, the default is true
				$config['cachedir']     = './assets/'; //string, the default is application/cache/
				$config['errorlog']     = './assets/'; //string, the default is application/logs/
				$config['imagedir']     = './assets/assets/img/qr/siswa/'; //direktori penyimpanan qr code
				$config['quality']      = true; //boolean, the default is true
				$config['size']         = '1024'; //interger, the default is 1024
				$config['black']        = array(224, 255, 255); // array, default is array(255,255,255)
				$config['white']        = array(70, 130, 180); // array, default is array(0,0,0)
				$this->ciqrcode->initialize($config);

				$image_name = $this->input->post('nisn') . '_' . $this->input->post('nama_siswa') . '.png'; //buat name dari qr code sesuai dengan nim

				$params['data'] = $this->input->post('nisn'); //data yang akan di jadikan QR CODE
				$params['level'] = 'H'; //H=High
				$params['size'] = 10;
				$params['savename'] = FCPATH . $config['imagedir'] . $image_name; //simpan image QR CODE ke folder assets/images/
				$this->ciqrcode->generate($params); // fungsi untuk generate QR CODE


				$config['upload_path']      = './assets/assets/img/siswa';
				$config['allowed_types']    = 'jpg|png|jpeg';
				$config['max_size']         = 10048;
				$config['file_name']        = 'File-' . date('ymd') . '-' . substr(sha1(rand()), 0, 10);
				$this->load->library('upload', $config);
				$this->upload->initialize($config);
				$this->upload->do_upload("photo");
				$data = $this->upload->data();
				$photo = $data['file_name'];
				$data = array(
					'nisn' => $this->input->post('nisn', TRUE),
					'nama_siswa' => $this->input->post('nama_siswa', TRUE),
					'jk_kelamin' => $this->input->post('jk_kelamin', TRUE),
					'kelas_id' => $this->input->post('kelas_id', TRUE),
					'alamat' => $this->input->post('alamat', TRUE),
					'tempat_lahir' => $this->input->post('tempat_lahir', TRUE),
					'tanggal_lahir' => $this->input->post('tanggal_lahir', TRUE),
					'nama_wali_siswa' => $this->input->post('nama_wali_siswa', TRUE),
					'no_hp_wali_siswa' => $this->input->post('no_hp_wali_siswa', TRUE),
					'photo' => $photo,
					'qr_code' => $image_name,
				);
				$this->Siswa_model->insert($data);
			}
			$this->session->set_flashdata('message', 'Create Record Success');
			redirect(site_url('siswa/daftar_siswa?kelas_id=' . $this->input->post('kelas_id', TRUE)));
		}
	}

	public function update($id)
	{
		check_admin();
		$row = $this->Siswa_model->get_by_id(decrypt_url($id));
		if($row->photo==''){
			$photo =set_value('photo', 'default.png');
		}else{
			$photo =set_value('photo', $row->photo);
		}


		if ($row) {
			$data = array(
				'button' => 'Update',
				'nisn_lama' => $row->nisn,
				'kelas' => $this->Kelas_model->get_all(),
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'action' => site_url('siswa/update_action'),
				'siswa_id' => set_value('siswa_id', $row->siswa_id),
				'nisn' => set_value('nisn', $row->nisn),
				'nama_siswa' => set_value('nama_siswa', $row->nama_siswa),
				'jk_kelamin' => set_value('jk_kelamin', $row->jk_kelamin),
				'kelas_id' => set_value('kelas_id', $row->kelas_id),
				'alamat' => set_value('alamat', $row->alamat),
				'tempat_lahir' => set_value('tempat_lahir', $row->tempat_lahir),
				'tanggal_lahir' => set_value('tanggal_lahir', $row->tanggal_lahir),
				'photo' => $photo,
				'nama_wali_siswa' => set_value('nama_wali_siswa', $row->nama_wali_siswa),
				'no_hp_wali_siswa' => set_value('no_hp_wali_siswa', $row->no_hp_wali_siswa),

			);
			$this->template->load('template', 'siswa/siswa_form', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('siswa'));
		}
	}

	public function update_action()
	{
		check_admin();
		$this->_rules('update', $this->input->post('nisn'), $this->input->post('nisn'));

		if ($this->form_validation->run() == FALSE) {
			$this->update(encrypt_url($this->input->post('siswa_id')));
		} else {
			if ($this->input->post('password') == '' || $this->input->post('password') == null) {
				$data = array(
					'username' => $this->input->post('nisn', TRUE),
					'level_id' => 4
				);
				$this->db->where('username', $this->input->post('nisn_lama'));
				$this->db->update('user', $data);
			} else {
				$data = array(
					'password' => sha1($this->input->post('password', TRUE)),
					'username' => $this->input->post('nisn', TRUE),
					'level_id' => 4
				);
				$this->db->where('username', $this->input->post('nisn_lama'));
				$this->db->update('user', $data);
			}

			// hapus qr code
			$id = $this->input->post('siswa_id');
			$row = $this->Siswa_model->get_by_id($id);
			if ($row->qr_code == null || $row->qr_code == '') {
			} else {
				$target_file = './assets/assets/img/qr/siswa/' . $row->qr_code;
				unlink($target_file);
			}

			// buat qr code baru
			$this->load->library('ciqrcode'); //pemanggilan library QR CODE
			$config['cacheable']    = true; //boolean, the default is true
			$config['cachedir']     = './assets/'; //string, the default is application/cache/
			$config['errorlog']     = './assets/'; //string, the default is application/logs/
			$config['imagedir']     = './assets/assets/img/qr/siswa/'; //direktori penyimpanan qr code
			$config['quality']      = true; //boolean, the default is true
			$config['size']         = '1024'; //interger, the default is 1024
			$config['black']        = array(224, 255, 255); // array, default is array(255,255,255)
			$config['white']        = array(70, 130, 180); // array, default is array(0,0,0)
			$this->ciqrcode->initialize($config);
			$image_name = $this->input->post('nisn') . '_' . $this->input->post('nama_siswa') . '.png'; //buat name dari qr code sesuai dengan nim
			$params['data'] = $this->input->post('nisn');

			// var_dump($params['data']);
			// die();

			$params['level'] = 'H'; //H=High
			$params['size'] = 10;
			$params['savename'] = FCPATH . $config['imagedir'] . $image_name;
			$this->ciqrcode->generate($params);

			$config['upload_path']      = './assets/assets/img/siswa';
			$config['allowed_types']    = 'jpg|png|jpeg';
			$config['max_size']         = 10048;
			$config['file_name']        = 'File-' . date('ymd') . '-' . substr(sha1(rand()), 0, 10);
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			if ($this->upload->do_upload("photo")) {
				$id = $this->input->post('siswa_id');
				$row = $this->Siswa_model->get_by_id($id);
				$data = $this->upload->data();
				$photo = $data['file_name'];
				if ($row->photo == null || $row->photo == '') {
				} else {
					$target_file = './assets/assets/img/siswa/' . $row->photo;
					unlink($target_file);
				}
			} else {
				$photo = $this->input->post('photo_lama');
			}

			$data = array(
				'nisn' => $this->input->post('nisn', TRUE),
				'nama_siswa' => $this->input->post('nama_siswa', TRUE),
				'jk_kelamin' => $this->input->post('jk_kelamin', TRUE),
				'kelas_id' => $this->input->post('kelas_id', TRUE),
				'alamat' => $this->input->post('alamat', TRUE),
				'tempat_lahir' => $this->input->post('tempat_lahir', TRUE),
				'tanggal_lahir' => $this->input->post('tanggal_lahir', TRUE),
				'nama_wali_siswa' => $this->input->post('nama_wali_siswa', TRUE),
				'no_hp_wali_siswa' => $this->input->post('no_hp_wali_siswa', TRUE),
				'photo' => $photo,
				'qr_code' => $image_name,
			);

			$this->Siswa_model->update($this->input->post('siswa_id', TRUE), $data);
			$this->session->set_flashdata('message', 'Update Record Success');
			redirect(site_url('siswa/daftar_siswa?kelas_id=' . $this->input->post('kelas_id', TRUE)));
		}
	}

	public function delete($id)
	{
		check_admin();
		$row = $this->Siswa_model->get_by_id(decrypt_url($id));

		if ($row) {
			if ($row->photo == null || $row->photo == '') {
			} else {
				$target_file = './assets/assets/img/siswa/' . $row->photo;
				unlink($target_file);
			}

			if ($row->qr_code == null || $row->qr_code == '') {
			} else {
				$target_file = './assets/assets/img/qr/siswa/' . $row->qr_code;
				unlink($target_file);
			}


			$this->Siswa_model->delete(decrypt_url($id));
			if ($this->db->affected_rows() > 0) {
				$this->db->where('username', $row->nisn);
				$this->db->delete('user');
			}
			$this->session->set_flashdata('message', 'Delete Record Success');
			redirect(site_url('siswa/daftar_siswa?kelas_id=' . $row->kelas_id));
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('siswa'));
		}
	}

	public function _rules($type, $new, $original_value)
	{

		if ($type != null) {
			if ($new == $original_value) {
				$is_unique =  '';
			} else {
				$is_unique =  '|is_unique[siswa.nisn]|is_unique[user.username]';
			}
		} else {
			$is_unique =  '|is_unique[siswa.nisn]|is_unique[user.username]';
			$this->form_validation->set_rules('password', 'Password', 'trim|required');
		}
		$this->form_validation->set_rules('nisn', 'nisn', 'trim|required' . $is_unique);
		$this->form_validation->set_rules('nama_siswa', 'nama siswa', 'trim|required');
		$this->form_validation->set_rules('jk_kelamin', 'jk kelamin', 'trim|required');
		$this->form_validation->set_rules('kelas_id', 'kelas id', 'trim|required');
		$this->form_validation->set_rules('alamat', 'alamat', 'trim|required');
		$this->form_validation->set_rules('tempat_lahir', 'tempat lahir', 'trim|required');
		$this->form_validation->set_rules('tanggal_lahir', 'tanggal lahir', 'trim|required');
		$this->form_validation->set_rules('no_hp_wali_siswa', 'no hp wali siswa', 'trim|required');
		$this->form_validation->set_rules('nama_wali_siswa', 'nama wali siswa', 'trim|required');
		$this->form_validation->set_rules('photo', 'photo', 'trim');

		$this->form_validation->set_rules('siswa_id', 'siswa_id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
	}

	public function export_excel()
	{
		check_admin();
		$kelas = $this->input->get('id', TRUE);
		$datany = array(
			'kelas' => $this->Kelas_model->get_by_id($kelas),
		);


		$spreadsheet = new Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();

		$sheet->setCellValue('A1', 'No');
		$sheet->setCellValue('B1', 'NISN');
		$sheet->setCellValue('C1', 'Nama Siswa');
		$sheet->setCellValue('D1', 'jk_kelamin');
		$sheet->setCellValue('E1', 'Kelas');
		$sheet->setCellValue('F1', 'alamat');
		$sheet->setCellValue('G1', 'tempat_lahir');
		$sheet->setCellValue('H1', 'tanggal_lahir');
		$sheet->setCellValue('I1', 'nama_wali_siswa');
		$sheet->setCellValue('J1', 'no_hp_wali_siswa');

		$siswa = $this->Siswa_model->get_all_siswa($kelas);
		$no = 1;
		$numrow = 2;
		foreach ($siswa as $data) {
			$sheet->setCellValue('A' . $numrow, $no);

			$sheet->setCellValue('B' . $numrow, $data->nisn);
			$sheet->setCellValue('C' . $numrow, $data->nama_siswa);
			$sheet->setCellValue('D' . $numrow, $data->jk_kelamin);
			$sheet->setCellValue('E' . $numrow, $datany['kelas']->nama_kelas);
			$sheet->setCellValue('F' . $numrow, $data->alamat);
			$sheet->setCellValue('G' . $numrow, $data->tempat_lahir);
			$sheet->setCellValue('H' . $numrow, $data->tanggal_lahir);
			$sheet->setCellValue('I' . $numrow, $data->nama_wali_siswa);
			$sheet->setCellValue('J' . $numrow, $data->no_hp_wali_siswa);
			$no++; // Tambah 1 setiap kali looping
			$numrow++; // Tambah 1 setiap kali looping
		}

		// var_dump($siswa);

		// Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
		$sheet->getDefaultRowDimension()->setRowHeight(-1);
		// Set judul file excel nya
		$sheet->setTitle("Data Siswa");
		// Proses file excel

		header('Content-Type: application/vnd.ms-excel'); // generate excel file
		header('Content-Disposition: attachment; filename="Data Siswa Kelas' . $datany['kelas']->nama_kelas . ' ' . date('Y-m-d') . '.xlsx"'); // Set nama file excel nya
		header('Cache-Control: max-age=0');
		ob_end_clean();
		$writer = new Xlsx($spreadsheet);
		$writer->save('php://output');
		die;
	}

	public function download($gambar)
	{
		check_admin();
		force_download('assets/assets/img/siswa/' . $gambar, NULL);
	}

	public function update_kelas($kelas_id)
	{
		check_admin();
		$siswa_id = $_POST['update'];
		if ($siswa_id == '' || $siswa_id == null) {
			echo "<script>
                  alert('Harap pilih salah satu siswa yang akan dipindahkan');
                  window.location='" . site_url('siswa/daftar_siswa?kelas_id=' . $kelas_id) . "'</script>";
		} else {
			$ket    = $_POST['kelas_id'];
			$jumlah_data = count($siswa_id);
			for ($i = 0; $i < $jumlah_data; $i++) {
				$sql = "Update siswa set kelas_id='$ket' where siswa_id='$siswa_id[$i]'";
				$this->db->query($sql);
			}
			echo "<script>
                  alert('Berhasil memindahkan siswa');
                  window.location='" . site_url('siswa/daftar_siswa?kelas_id=' . $kelas_id) . "'</script>";
		}
	}

	public function cetak_semua()
	{
		check_admin();
		$kelas_id = $_GET['kelas_id'];
		$siswa = $this->Siswa_model->get_all($kelas_id);
		$data = array(
			'siswa' => $siswa,
			'kelas_id' => $kelas_id,
			'kelas' => $this->Kelas_model->get_all(),
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);

		$this->load->view('siswa/cetak_semua', $data);
	}

	public function cetak($id)
	{
		$row = $this->Siswa_model->get_by_id(decrypt_url($id));
		$data = array(
			'siswa_id' => $row->siswa_id,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'nisn' => $row->nisn,
			'nama_siswa' => $row->nama_siswa,
			'jk_kelamin' => $row->jk_kelamin,
			'kelas_id' => $row->kelas_id,
			'alamat' => $row->alamat,
			'tempat_lahir' => $row->tempat_lahir,
			'tanggal_lahir' => $row->tanggal_lahir,
			'photo' => $row->photo,
			'nama_wali_siswa' => $row->nama_wali_siswa,
			'no_hp_wali_siswa' => $row->no_hp_wali_siswa,
			'qr_code' => $row->qr_code,

		);
		$this->load->view('siswa/cetak', $data);
	}

	public function preview_excel()
	{
		$str = '';
		$fileName = $_FILES['file_excel']['name'];
		$kelas = $this->input->post('kelas');

		$config['upload_path'] = './temp_doc/'; //path upload
		$config['file_name'] = $fileName;  // nama file
		$config['allowed_types'] = 'xls|xlsx'; //tipe file yang diperbolehkan
		$config['max_size'] = 10000; // maksimal sizze

		$this->load->library('upload'); //meload librari upload
		$this->upload->initialize($config);

		if (!$this->upload->do_upload('file_excel')) {
			// echo $this->upload->display_errors();
			echo json_encode([
				'status' => 'no',
				'message' => $this->upload->display_errors()
			]);
			exit();
		}

		$inputFileName = './temp_doc/' . $this->upload->data('file_name');

		try {

			$inputFileType = IOFactory::identify($inputFileName);
			$objReader = IOFactory::createReader($inputFileType);
			$objExcel = $objReader->load($inputFileName);
		} catch (Exception $e) {
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e->getMessage());
		}

		$sheet = $objExcel->getActiveSheet()->toArray(null, true, true, true);
		$sh = $objExcel->getActiveSheet();

		$numrow = 1;

		for ($i = 3; $i <= count($sheet); $i++) {
			$kategoridata = $sh->getCellByColumnAndRow(1, 1)->getValue();

			$identity_number = $sheet[$i]['A'];
			$nama_siswa = $sheet[$i]['B'];
			$jenis_kelamin = $sheet[$i]['C'];
			// $kelas_id = $sheet[$i]['D'];
			$alamat = $sheet[$i]['D'];
			$tempat_lahir = $sheet[$i]['E'];
			$tanggal_lahir = $sheet[$i]['F'];
			$nama_wali_siswa = $sheet[$i]['G'];
			$no_hp_wali_siswa = $sheet[$i]['H'];
			$password = $sheet[$i]['I'];

			$realcount = $i - 1;

			// get nama kelas and jenjang kelas by $kelas_id
			$kelasny = $this->Kelas_model->get_by_id($kelas)->nama_kelas;

			$cekdatadidb = $this->User_model->get_by_username($identity_number);
			if ($cekdatadidb) {
				$str .= '<tr class="bg-danger not-allowed-to-insert-excel">
							<td>' . $identity_number . '</td>
							<td>' . $nama_siswa . '</td>
							<td>' . $jenis_kelamin . '</td>
							<td>' . $kelasny . '</td>
							<td>' . $alamat . '</td>
							<td>' . $tempat_lahir . '</td>
							<td>' . $tanggal_lahir . '</td>
							<td>' . $nama_wali_siswa . '</td>
							<td>' . $no_hp_wali_siswa . '</td>
							<td>' . $password . '</td>
						</tr>';
			} else {
				$str .= '<tr>
							<td>' . $identity_number . '<input type="hidden" value="' . $identity_number . '" class="nisn" name="nisn[]"/></td>
							<td>' . $nama_siswa . '<input type="hidden" value="' . $nama_siswa . '" class="nama_siswa" name="nama_siswa[]"/></td>
							<td>' . $jenis_kelamin . '<input type="hidden" value="' . $jenis_kelamin . '" class="jenis_kelamin" name="jenis_kelamin[]"/></td>
							<td>' . $kelasny . '<input type="hidden" value="' . $kelas . '" class="kelas" name="kelas[]"/></td>
							<td>' . $alamat . '<input type="hidden" value="' . $alamat . '" class="alamat" name="alamat[]"/></td>
							<td>' . $tempat_lahir . '<input type="hidden" value="' . $tempat_lahir . '" class="tempat_lahir" name="tempat_lahir[]"/></td>
							<td>' . $tanggal_lahir . '<input type="hidden" value="' . $tanggal_lahir . '" class="tanggal_lahir" name="tanggal_lahir[]"/></td>
							<td>' . $nama_wali_siswa . '<input type="hidden" value="' . $nama_wali_siswa . '" class="nama_wali_siswa" name="nama_wali_siswa[]"/></td>
							<td>' . $no_hp_wali_siswa . '<input type="hidden" value="' . $no_hp_wali_siswa . '" class="no_hp_wali_siswa" name="no_hp_wali_siswa[]"/></td>

							<td>' . $password . '<input type="hidden" value="' . $password . '" class="password" name="password[]"/></td>
						</tr>';
			}

			$numrow++;
		}
		//print_r($arraysoaldata);

		unlink($inputFileName);
		$arrayresp = array(
			'status' => 'ok',
			'message' => 'success',
			'data' => $str
		);
		echo json_encode($arrayresp);
	}

	public function insert_all_from_excel()
	{
		$nisn = $this->input->post('nisn');
		$nama_siswa = $this->input->post('nama_siswa');
		$jenis_kelamin = $this->input->post('jenis_kelamin');
		$kelas_id = $this->input->post('kelas');
		$alamat = $this->input->post('alamat');
		$tempat_lahir = $this->input->post('tempat_lahir');
		$tanggal_lahir = $this->input->post('tanggal_lahir');
		$password = $this->input->post('password');

		$nama_wali_siswa = $this->input->post('nama_wali_siswa');
		$no_hp_wali_siswa = $this->input->post('no_hp_wali_siswa');

		foreach ($nisn as $key => $value) {
			$data2 = array(
				'password' => sha1($password[$key]),
				'username' => $value,
				'level_id' => 4
			);

			$this->db->insert('user', $data2);
			// qr code
			$this->load->library('ciqrcode'); //pemanggilan library QR CODE

			$config['cacheable']    = true; //boolean, the default is true
			$config['cachedir']     = './assets/'; //string, the default is application/cache/
			$config['errorlog']     = './assets/'; //string, the default is application/logs/
			$config['imagedir']     = './assets/assets/img/qr/siswa/'; //direktori penyimpanan qr code
			$config['quality']      = true; //boolean, the default is true
			$config['size']         = '1024'; //interger, the default is 1024
			$config['black']        = array(224, 255, 255); // array, default is array(255,255,255)
			$config['white']        = array(70, 130, 180); // array, default is array(0,0,0)
			$this->ciqrcode->initialize($config);

			$image_name = $value . '_' . $nama_siswa[$key] . '.png'; //buat name dari qr code sesuai dengan nim

			$params['data'] = $value; //data yang akan di jadikan QR CODE
			$params['level'] = 'H'; //H=High
			$params['size'] = 10;
			$params['savename'] = FCPATH . $config['imagedir'] . $image_name; //simpan image QR CODE ke folder assets/images/
			$this->ciqrcode->generate($params); // fungsi untuk generate QR CODE
			$data = array(
				'nisn' => $value,
				'nama_siswa' => $nama_siswa[$key],
				'jk_kelamin' => $jenis_kelamin[$key],
				'kelas_id' => $kelas_id[$key],
				'alamat' => $alamat[$key],
				'tempat_lahir' => $tempat_lahir[$key],
				'tanggal_lahir' => date('Y-m-d', strtotime($tanggal_lahir[$key])),
				'photo' => '',
				'qr_code' => $image_name,
				'nama_wali_siswa' => $nama_wali_siswa[$key],
				'no_hp_wali_siswa' => $no_hp_wali_siswa[$key],
			);
			$this->Siswa_model->insert($data);
		}
		$this->session->set_flashdata('message', 'Create Record Success');
		redirect(site_url('siswa'));
	}
}
