<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Jenjang extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		is_login();
		check_admin();
		$this->load->model('Jenjang_model');
		$this->load->model('App_setting_model');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$jenjang = $this->Jenjang_model->get_all();
		$data = array(
			'jenjang_data' => $jenjang,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('template', 'jenjang/jenjang_list', $data);
	}

	public function read($id)
	{
		$row = $this->Jenjang_model->get_by_id(decrypt_url($id));
		if ($row) {
			$data = array(
				'jenjang_id' => $row->jenjang_id,
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'nama_jenjang' => $row->nama_jenjang,
			);
			$this->template->load('template', 'jenjang/jenjang_read', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('jenjang'));
		}
	}

	public function create()
	{
		$data = array(
			'button' => 'Create',
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'action' => site_url('jenjang/create_action'),
			'jenjang_id' => set_value('jenjang_id'),
			'nama_jenjang' => set_value('nama_jenjang'),
		);
		$this->template->load('template', 'jenjang/jenjang_form', $data);
	}

	public function create_action()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->create();
		} else {
			$data = array(
				'nama_jenjang' => $this->input->post('nama_jenjang', TRUE),
			);

			$this->Jenjang_model->insert($data);
			$this->session->set_flashdata('message', 'Create Record Success');
			redirect(site_url('jenjang'));
		}
	}

	public function update($id)
	{
		$row = $this->Jenjang_model->get_by_id(decrypt_url($id));

		if ($row) {
			$data = array(
				'button' => 'Update',
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'action' => site_url('jenjang/update_action'),
				'jenjang_id' => set_value('jenjang_id', $row->jenjang_id),
				'nama_jenjang' => set_value('nama_jenjang', $row->nama_jenjang),
			);
			$this->template->load('template', 'jenjang/jenjang_form', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('jenjang'));
		}
	}

	public function update_action()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->update(encrypt_url($this->input->post('jenjang_id')));
		} else {
			$data = array(
				'nama_jenjang' => $this->input->post('nama_jenjang', TRUE),
			);

			$this->Jenjang_model->update($this->input->post('jenjang_id', TRUE), $data);
			$this->session->set_flashdata('message', 'Update Record Success');
			redirect(site_url('jenjang'));
		}
	}

	public function delete($id)
	{
		$row = $this->Jenjang_model->get_by_id(decrypt_url($id));

		if ($row) {
			$this->Jenjang_model->delete(decrypt_url($id));

			$error = $this->db->error();
			if ($error['code'] != 0) {
				$this->session->set_flashdata('error', 'Tidak dapat dihapus data sudah berrelasi');
			} else {
				$this->session->set_flashdata('message', 'Delete Record Success');
			}
			redirect(site_url('jenjang'));
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('jenjang'));
		}
	}

	public function _rules()
	{
		$this->form_validation->set_rules('nama_jenjang', 'nama jenjang', 'trim|required');

		$this->form_validation->set_rules('jenjang_id', 'jenjang_id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
	}

	public function excel()
	{
		$this->load->helper('exportexcel');
		$namaFile = "jenjang.xls";
		$judul = "jenjang";
		$tablehead = 0;
		$tablebody = 1;
		$nourut = 1;
		//penulisan header
		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");
		header("Content-Disposition: attachment;filename=" . $namaFile . "");
		header("Content-Transfer-Encoding: binary ");

		xlsBOF();

		$kolomhead = 0;
		xlsWriteLabel($tablehead, $kolomhead++, "No");
		xlsWriteLabel($tablehead, $kolomhead++, "Nama Jenjang");

		foreach ($this->Jenjang_model->get_all() as $data) {
			$kolombody = 0;

			//ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
			xlsWriteNumber($tablebody, $kolombody++, $nourut);
			xlsWriteLabel($tablebody, $kolombody++, $data->nama_jenjang);

			$tablebody++;
			$nourut++;
		}

		xlsEOF();
		exit();
	}
}

/* End of file Jenjang.php */
/* Location: ./application/controllers/Jenjang.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2022-01-10 16:04:19 */
/* http://harviacode.com */
