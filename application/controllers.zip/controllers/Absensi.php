<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');
date_default_timezone_set('Asia/Jayapura');
header('Access-Control-Allow-Origin: *');

header('Access-Control-Allow-Methods: GET, POST');

header("Access-Control-Allow-Headers: X-Requested-With");

class Absensi extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('Kelas_model');
		$this->load->model('user_m');
		$this->load->model('Absen_model');
		$this->load->model('App_setting_model');
		$this->load->model('Pengumuman_model');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$query = $this->db->query("SELECT * From halaman_absensi where halaman_absensi_id='1' ");
		$row = $query->row();
		$absen = $this->Absen_model->get_all();
		$tanggal_hari_ini = date('Y-m-d');
		$cekharilibur = $this->db->query("SELECT * FROM hari_libur WHERE date(tanggal)='" . $tanggal_hari_ini . "'")->row();
		if ($row->is_aktif == 'Aktif') {

			if ($cekharilibur) {
				$this->load->view('halaman_absensi_mt');
			} else if (date('D') == 'Sun') {
				$this->load->view('halaman_absensi_mt');
			} else {
				$lock_screen = $this->session->userdata('un_lock');
				if (!$lock_screen) {
					$data = array(
						'sett_apps' => $this->App_setting_model->get_by_id(1)
					);
					$this->load->view('lock_screen', $data);
				} else {
					$peng = $this->Pengumuman_model->get_by_id(1);
					$dt = $this->db->query("SELECT * FROM waktu_absen WHERE nama_hari='" . hari_ini() . "';")->row();
					$data = array(
						'sett_apps' => $this->App_setting_model->get_by_id(1),
						'status_pengumuman' => $peng->status,
						'absen_data' => $absen,
						'text' => $peng->text,
						'jam_masuk_m' => $dt->jam_masuk_siswa,
						'jam_keluar_m' => $dt->jam_pulang_siswa,
						'jam_masuk_p_g' => $dt->jam_masuk_guru,
						'jam_keluar_p_g' => $dt->jam_pulang_guru,
						'dataabsen' => $this->Absen_model->get_all_absen_today(date('Y-m-d'))
					);
					$this->load->view('halaman_absensi', $data);
				}
			}
		} else {
			$this->load->view('halaman_absensi_mt');
		}
	}

	public function un_lock()
	{
		$post = $this->input->post(null, TRUE);
		if (isset($post['un_lock'])) {
			$query = $this->user_m->un_lock($post);
			if ($query->num_rows() > 0) {
				$row = $query->row();
				$params = array(
					'un_lock' => $row->is_aktif,
				);
				$this->session->set_userdata($params);
				echo "<script>window.location='" . site_url('absensi') . "'</script>";
			} else {
				$this->session->set_flashdata('error', 'Password Salah');
				redirect(site_url('absensi'));
			}
		}
	}

	public function show_latest_absen()
	{
		$data = $this->Absen_model->get_all_absen_today(date('Y-m-d'));
		$str = '';
		foreach ($data as $absen) {

			$getdatauser = $this->get_data_user_by_user_id($absen->user_id);
			$name = 'null';
			$level = 'null';
			// var_dump($getdatauser->username);
			if ($getdatauser->level_id == 1) {
				$name = 'Admin Aplikasi';
				$level = 'Admin Aplikasi';
			}
			if ($getdatauser->level_id == 2) {
				$name = nama_guru($getdatauser->user_id);
				$level = 'Guru';
			}
			if ($getdatauser->level_id == 3) {
				$name = nama_pegawai($getdatauser->user_id);
				$level = 'Pegawai';
			}
			if ($getdatauser->level_id == 4) {
				$name = nama_siswa($getdatauser->user_id);
				$level = 'Murid';
			}

			$sts_m = '';
			$sts_k = '';

			if ($absen->status_masuk == 'Terlambat') {
				$sts_m = '<i class="fas fa-exclamation-circle" style="color: #ff3502;"></i>';
			}
			if ($absen->status_masuk == 'Tepat Waktu') {
				$sts_m = '<i class="fas fa-check-circle" style="color: #04c142;"></i>';
			}
			if ($absen->status_pulang == 'Terlambat') {
				$sts_k = '<i class="fas fa-exclamation-circle" style="color: #ff3502;"></i>';
			}
			if ($absen->status_pulang == 'Tepat Waktu') {

				$sts_k = '<i class="fas fa-check-circle" style="color: #04c142;"></i>';
			}

			$str .= '<tr>
						<td>' . $name . '</td>
						<td>' . $level . '</td>
						<td>' . $absen->tanggal . '</td>
						<td>' . $absen->keterangan . '</td>
						<td>' . $absen->jam_masuk . ' <span>' . $sts_m . '</span></td>
						<td>' . $absen->jam_pulang . ' <span>' . $sts_k . '</span></td>
					</tr>';
		}

		return $str;
	}

	public function cek_telat($id_user)
	{
		$cek_hari  = date('D'); //Tune hari ini
		$hari_ini = '';
		switch ($cek_hari) {
			case 'Sun':
				$hari_ini = "Minggu";
				break;
			case 'Mon':
				$hari_ini = "Senin";
				break;

			case 'Tue':
				$hari_ini = "Selasa";
				break;

			case 'Wed':
				$hari_ini = "Rabu";
				break;

			case 'Thu':
				$hari_ini = "Kamis";
				break;

			case 'Fri':
				$hari_ini = "Jumat";
				break;

			case 'Sat':
				$hari_ini = "Sabtu";
				break;

			default:
				$hari_ini = "Unknown";
				break;
		}

		$dtabsentime = $this->db->query("SELECT * FROM waktu_absen WHERE nama_hari='" . $hari_ini . "'")->row();
		if ($dtabsentime) {

			$datausersipengabsen = $this->db->query("SELECT * FROM user WHERE user_id='" . $id_user . "'")->row();
			if ($datausersipengabsen->level_id == 2) {
				$late_waktu_absen = $dtabsentime->jam_masuk_guru;
				$minutes_to_add = $dtabsentime->absen_terlambat_guru;
			}
			if ($datausersipengabsen->level_id == 3) {
				$late_waktu_absen = $dtabsentime->jam_masuk_guru;
				$minutes_to_add = $dtabsentime->absen_terlambat_guru;
			}
			if ($datausersipengabsen->level_id == 4) {
				$late_waktu_absen = $dtabsentime->jam_masuk_siswa;
				$minutes_to_add = $dtabsentime->absen_terlambat_siswa;
			}
			$time = new DateTime($late_waktu_absen);
			$time->add(new DateInterval('PT' . $minutes_to_add . 'M'));
			$stamp = $time->format('H:i');
			$now = date('H:i'); //tune

			$status = '';
			if ($now > $stamp) {
				return 'ya'; //telat
			} else {
				return 'ga'; //tidak telat
			}
		}
	}

	public function insert_absen_data($id_user, $kode)
	{
		$cekdataabsenmasuk = $this->Absen_model->cek_data_absen_masuk($id_user);

		// $cek_hari  = 'Mon';
		$cek_hari  = date('D'); //Tune hari ini
		$hari_ini = '';
		switch ($cek_hari) {
			case 'Sun':
				$hari_ini = "Minggu";
				break;
			case 'Mon':
				$hari_ini = "Senin";
				break;

			case 'Tue':
				$hari_ini = "Selasa";
				break;

			case 'Wed':
				$hari_ini = "Rabu";
				break;

			case 'Thu':
				$hari_ini = "Kamis";
				break;

			case 'Fri':
				$hari_ini = "Jumat";
				break;

			case 'Sat':
				$hari_ini = "Sabtu";
				break;

			default:
				$hari_ini = "Unknown";
				break;
		}

		$dtabsentime = $this->db->query("SELECT * FROM waktu_absen WHERE nama_hari='" . $hari_ini . "'")->row();
		if ($dtabsentime) {

			$datausersipengabsen = $this->db->query("SELECT * FROM user WHERE user_id='" . $id_user . "'")->row();
			if ($datausersipengabsen->level_id == 2) {
				$late_waktu_absen = $dtabsentime->jam_masuk_guru;
				$minutes_to_add = $dtabsentime->absen_terlambat_guru;
			}
			if ($datausersipengabsen->level_id == 3) {
				$late_waktu_absen = $dtabsentime->jam_masuk_guru;
				$minutes_to_add = $dtabsentime->absen_terlambat_guru;
			}
			if ($datausersipengabsen->level_id == 4) {
				$late_waktu_absen = $dtabsentime->jam_masuk_siswa;
				$minutes_to_add = $dtabsentime->absen_terlambat_siswa;
			}
			$time = new DateTime($late_waktu_absen);
			$time->add(new DateInterval('PT' . $minutes_to_add . 'M'));
			$stamp = $time->format('H:i');
			$now = date('H:i'); //tune

			$status = '';
			if ($now > $stamp) {
				$status = 'Terlambat';
			} else {
				$status = 'Tepat Waktu';
			}

			if ($cekdataabsenmasuk) {
				$cekabsenkeluar = $this->Absen_model->cek_data_absen_keluar($id_user);
				if (!$cekabsenkeluar) {
					return 'no';
				} else {

					$datapulang = $this->db->query("SELECT * FROM waktu_absen WHERE nama_hari='" . $hari_ini . "'")->row();
					$allowedtopulang = 0;
					if ($datausersipengabsen->level_id == 2) {
						if ($now >= $datapulang->jam_pulang_guru) {
							$allowedtopulang = 1;
						}
					}
					if ($datausersipengabsen->level_id == 3) {
						if ($now >= $datapulang->jam_pulang_guru) {
							$allowedtopulang = 1;
						}
					}
					if ($datausersipengabsen->level_id == 4) {
						if ($now >= $datapulang->jam_pulang_siswa) {
							$allowedtopulang = 1;
						}
					}

					if ($allowedtopulang == 1) {
						$jam_pulang = date('H:i:s');
						$tgl = date('Y-m-d');

						$datatoupdate = array(
							'jam_pulang' => $jam_pulang,
							'status_pulang' => 'Tepat Waktu'
						);

						$this->Absen_model->update($cekabsenkeluar->absen_id, $datatoupdate);
						$no_hp = no_hp_wali($id_user);
						$fix_no = $no_hp . '@c.us';
						$nama_siswa = nama_siswa($id_user);
						// kirim pesan wa
						$cek_dlu = $this->App_setting_model->get_by_id(1);
						$is = $cek_dlu->wa_blast;
						if ($is == 'Aktif') {
							$url = 'http:';
							$ch = curl_init($url);
							$data = array(
								'number' => $fix_no,
								'message' => 'Assalamualaikum Wr Wb Bapak/Ibu wali murid, Ananda ' . $nama_siswa . ', Absen pulang tanggal ' . $tgl . ', pada jam ' . $jam_pulang . ', Terimakasih !!!'
							);
							$payload = json_encode($data);
							curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
							curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
							$result = curl_exec($ch);
							curl_close($ch);
						}
						return 'ok';
					} else {
						return 'not allowed pulang';
					}
				}
			} else {
				$jam_masuk = date('H:i:s');
				$tgl = date('Y-m-d');
				$dataabsentoinsert = array(
					'user_id' => $id_user,
					'tanggal' => $tgl,
					'keterangan' => 'Masuk',
					'jam_masuk' => $jam_masuk,
					'jam_pulang' => NULL,
					'status_masuk' => $status
				);

				$this->Absen_model->insert($dataabsentoinsert);

				// kirim wa
				$no_hp = no_hp_wali($id_user);
				$fix_no = $no_hp . '@c.us';
				$nama_siswa = nama_siswa($id_user);
				// kirim pesan wa
				$cek_dlu = $this->App_setting_model->get_by_id(1);
				$is = $cek_dlu->wa_blast;
				if ($is == 'Aktif') {
					$url = 'http:///v2/send-message';
					$ch = curl_init($url);
					$data = array(
						'number' => $fix_no,
						'message' => 'Assalamualaikum Wr Wb Bapak/Ibu wali murid, Ananda ' . $nama_siswa . ', Absen masuk tanggal ' . $tgl . ', pada jam ' . $jam_masuk . ' status ' . $status . ', Terimakasih !!!'
					);
					$payload = json_encode($data);
					curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
					curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					$result = curl_exec($ch);
					curl_close($ch);
				}
				return 'ok';
			}
		} else {
			return 'holiday';
		}
	}

	public function get_data_user($id_user)
	{
		$data = $this->db->query("SELECT * FROM user WHERE username='" . $id_user . "'")->row();
		return $data;
	}
	public function get_data_user_by_user_id($user_id)
	{
		$data = $this->db->query("SELECT * FROM user WHERE user_id='" . $user_id . "'")->row();
		return $data;
	}

	public function get_info_absen()
	{
		$post = $this->input->post('codeny', TRUE);
		$ceksiswa = $this->Absen_model->cek_siswa($post);
		$cekguru = $this->Absen_model->cek_guru($post);
		$cekpegawai = $this->Absen_model->cek_karyawan($post);
		$getdatauser = $this->get_data_user($post);
		if ($ceksiswa) {
			$datasiswa = $this->Absen_model->get_data_siswa($post);
			if ($getdatauser) {
				$row = $datasiswa->row();
				if ($row->photo == '' || $row->photo == null) {
					$photo = 'default.png';
				} else {
					$photo = $row->photo;
				}
				$ceklgi = $this->insert_absen_data($getdatauser->user_id, $post);
				if ($ceklgi == 'ok') {
					$data = array(
						'response' => 'ok',
						'message' => 'found',
						'type' => 'siswa',
						'kode' => $row->nisn,
						'nama' => $row->nama_siswa,
						'photo' => $photo,
						'list_absensi' => $this->show_latest_absen(),
						'telatkah' => $this->cek_telat($getdatauser->user_id)
					);



					echo json_encode($data);
				}

				if ($ceklgi == 'no') {
					$data = array(
						'response' => 'not allowed',
						'message' => 'Absen Sudah dilakukan hari ini',
						'list_absensi' => $this->show_latest_absen()
					);
					echo json_encode($data);
				}

				if ($ceklgi == 'holiday') {
					$data = array(
						'response' => 'holiday',
						'message' => 'Hari Libur'
					);
					echo json_encode($data);
				}

				if ($ceklgi == 'not allowed pulang') {
					$data = array(
						'response' => 'not allowed pulang',
						'message' => 'Absen pulang tidak diperbolehkan',
						'list_absensi' => $this->show_latest_absen()
					);
					echo json_encode($data);
				}
			}
		} else if ($cekguru) {
			$dataguru = $this->Absen_model->get_data_guru($post);
			$row = $dataguru->row();
			if ($row->photo == '' || $row->photo == null) {
				$photo = 'default.png';
			} else {
				$photo = $row->photo;
			}
			$ceklgi = $this->insert_absen_data($getdatauser->user_id, $post);
			if ($ceklgi == 'ok') {
				$data = array(
					'response' => 'ok',
					'message' => 'found',
					'type' => 'guru',
					'kode' => $row->nip,
					'nama' => $row->nama_guru,
					'photo' => $photo,
					'list_absensi' => $this->show_latest_absen(),
					'telatkah' => $this->cek_telat($getdatauser->user_id)
				);
				echo json_encode($data);
			}

			if ($ceklgi == 'no') {
				$data = array(
					'response' => 'not allowed',
					'message' => 'Absen Sudah dilakukan hari ini',
					'list_absensi' => $this->show_latest_absen()
				);
				echo json_encode($data);
			}

			if ($ceklgi == 'holiday') {
				$data = array(
					'response' => 'holiday',
					'message' => 'Hari Libur'
				);
				echo json_encode($data);
			}

			if ($ceklgi == 'not allowed pulang') {
				$data = array(
					'response' => 'not allowed pulang',
					'message' => 'Absen pulang tidak diperbolehkan',
					'list_absensi' => $this->show_latest_absen()
				);
				echo json_encode($data);
			}
		} else if ($cekpegawai) {
			$datapegawai = $this->Absen_model->get_data_pegawai($post);
			$row = $datapegawai->row();
			if ($row->photo == '' || $row->photo == null) {
				$photo = 'default.png';
			} else {
				$photo = $row->photo;
			}
			$ceklgi = $this->insert_absen_data($getdatauser->user_id, $post);
			if ($ceklgi == 'ok') {
				$data = array(
					'response' => 'ok',
					'message' => 'found',
					'type' => 'pegawai',
					'kode' => $row->nip,
					'nama' => $row->nama_pegawai,
					'photo' => $photo,
					'list_absensi' => $this->show_latest_absen(),
					'telatkah' => $this->cek_telat($getdatauser->user_id)
				);
				echo json_encode($data);
			}

			if ($ceklgi == 'no') {
				$data = array(
					'response' => 'not allowed',
					'message' => 'Absen Sudah dilakukan hari ini',
					'list_absensi' => $this->show_latest_absen()
				);
				echo json_encode($data);
			}

			if ($ceklgi == 'holiday') {
				$data = array(
					'response' => 'holiday',
					'message' => 'Hari Libur'
				);
				echo json_encode($data);
			}

			if ($ceklgi == 'not allowed pulang') {
				$data = array(
					'response' => 'not allowed pulang',
					'message' => 'Absen pulang tidak diperbolehkan',
					'list_absensi' => $this->show_latest_absen()
				);
				echo json_encode($data);
			}
		} else {

			$data = array(
				'response' => 'not found',
				'message' => 'Data Tidak Ditemukan',
				'list_absensi' => $this->show_latest_absen()
			);
			echo json_encode($data);
		}
	}
}
