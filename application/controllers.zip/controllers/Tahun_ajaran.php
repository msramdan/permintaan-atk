<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

date_default_timezone_set('Asia/Jayapura');
class Tahun_ajaran extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		is_login();
		$this->load->model('Tahun_ajaran_model');
		$this->load->model('App_setting_model');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$tahun_ajaran = $this->Tahun_ajaran_model->get_all();
		$data = array(
			'tahun_ajaran_data' => $tahun_ajaran,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('template', 'tahun_ajaran/tahun_ajaran_list', $data);
	}

	public function read($id)
	{
		$row = $this->Tahun_ajaran_model->get_by_id(decrypt_url($id));
		if ($row) {
			$data = array(
				'tahun_ajaran_id' => $row->tahun_ajaran_id,
				'nama_tahun_ajaran' => $row->nama_tahun_ajaran,
				'tgl_awal' => $row->tgl_awal,
				'tgl_akhir' => $row->tgl_akhir,
				'sett_apps' => $this->App_setting_model->get_by_id(1),
			);
			$this->template->load('template', 'tahun_ajaran/tahun_ajaran_read', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('tahun_ajaran'));
		}
	}

	public function create()
	{
		$data = array(
			'button' => 'Create',
			'action' => site_url('tahun_ajaran/create_action'),
			'tahun_ajaran_id' => set_value('tahun_ajaran_id'),
			'nama_tahun_ajaran' => set_value('nama_tahun_ajaran'),
			'tgl_awal' => set_value('tgl_awal', date('Y-m-d')),
			'tgl_akhir' => set_value('tgl_akhir', date('Y-m-d')),
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('template', 'tahun_ajaran/tahun_ajaran_form', $data);
	}

	public function create_action()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->create();
		} else {

			// detect if there is any data within range of tgl_awal and tgl_akhir from table tahun_ajaran
			$nama_tahun_ajaran = $this->input->post('nama_tahun_ajaran', TRUE);
			$tgl_awal = $this->input->post('tgl_awal', TRUE);
			$tgl_akhir = $this->input->post('tgl_akhir', TRUE);
			$cektahunajaran = $this->deteksi_tahun_ajaran($tgl_awal, $tgl_akhir, 0);

			if (!$cektahunajaran) {
				$this->session->set_flashdata('message', 'Sudah ada tahun ajaran pada tanggal yang dipilih, silahkan buat tahun ajaran dengan tanggal lain');
				redirect(site_url('tahun_ajaran/create'));
			} else {
				$data = array(
					'nama_tahun_ajaran' => $nama_tahun_ajaran,
					'tgl_awal' => $tgl_awal,
					'tgl_akhir' => $tgl_akhir,
				);

				$this->Tahun_ajaran_model->insert($data);
				$this->session->set_flashdata('message', 'Create Record Success');
				redirect(site_url('tahun_ajaran'));
			}
		}
	}

	public function update($id)
	{
		$row = $this->Tahun_ajaran_model->get_by_id(decrypt_url($id));

		if ($row) {
			$data = array(
				'button' => 'Update',
				'action' => site_url('tahun_ajaran/update_action'),
				'tahun_ajaran_id' => set_value('tahun_ajaran_id', $row->tahun_ajaran_id),
				'nama_tahun_ajaran' => set_value('nama_tahun_ajaran', $row->nama_tahun_ajaran),
				'tgl_awal' => set_value('tgl_awal', $row->tgl_awal),
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'tgl_akhir' => set_value('tgl_akhir', $row->tgl_akhir),
			);
			$this->template->load('template', 'tahun_ajaran/tahun_ajaran_form', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('tahun_ajaran'));
		}
	}

	public function update_action()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->update($this->input->post('tahun_ajaran_id', TRUE));
		} else {
			$tahunajaranid = $this->input->post('tahun_ajaran_id', TRUE);
			$nama_tahun_ajaran = $this->input->post('nama_tahun_ajaran', TRUE);
			$tgl_awal = $this->input->post('tgl_awal', TRUE);
			$tgl_akhir = $this->input->post('tgl_akhir', TRUE);


			$cektahunajaran = $this->deteksi_tahun_ajaran($tgl_awal, $tgl_akhir, 0);

			if (!$cektahunajaran) {
				$this->session->set_flashdata('message', 'Sudah ada tahun ajaran pada tanggal yang dipilih, silahkan buat tahun ajaran dengan tanggal lain');
				redirect(site_url('tahun_ajaran/update/' . encrypt_url($tahunajaranid)));
			} else {
				$data = array(
					'nama_tahun_ajaran' => $nama_tahun_ajaran,
					'tgl_awal' => $tgl_awal,
					'tgl_akhir' => $tgl_akhir,
				);

				$this->Tahun_ajaran_model->update($tahunajaranid, $data);
				$this->session->set_flashdata('message', 'Update Record Success');
				redirect(site_url('tahun_ajaran'));
			}
		}
	}

	public function delete($id)
	{
		$row = $this->Tahun_ajaran_model->get_by_id(decrypt_url($id));

		if ($row) {
			$this->Tahun_ajaran_model->delete(decrypt_url($id));
			$this->session->set_flashdata('message', 'Delete Record Success');
			redirect(site_url('tahun_ajaran'));
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('tahun_ajaran'));
		}
	}

	public function _rules()
	{
		$this->form_validation->set_rules('nama_tahun_ajaran', 'nama tahun ajaran', 'trim|required');
		$this->form_validation->set_rules('tgl_awal', 'tgl awal', 'trim|required');
		$this->form_validation->set_rules('tgl_akhir', 'tgl akhir', 'trim|required');

		$this->form_validation->set_rules('tahun_ajaran_id', 'tahun_ajaran_id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
	}

	public function excel()
	{
		$this->load->helper('exportexcel');
		$namaFile = "tahun_ajaran.xls";
		$judul = "tahun_ajaran";
		$tablehead = 0;
		$tablebody = 1;
		$nourut = 1;
		//penulisan header
		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");
		header("Content-Disposition: attachment;filename=" . $namaFile . "");
		header("Content-Transfer-Encoding: binary ");

		xlsBOF();

		$kolomhead = 0;
		xlsWriteLabel($tablehead, $kolomhead++, "No");
		xlsWriteLabel($tablehead, $kolomhead++, "Nama Tahun Ajaran");
		xlsWriteLabel($tablehead, $kolomhead++, "Tgl Awal");
		xlsWriteLabel($tablehead, $kolomhead++, "Tgl Akhir");

		foreach ($this->Tahun_ajaran_model->get_all() as $data) {
			$kolombody = 0;

			//ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
			xlsWriteNumber($tablebody, $kolombody++, $nourut);
			xlsWriteLabel($tablebody, $kolombody++, $data->nama_tahun_ajaran);
			xlsWriteLabel($tablebody, $kolombody++, $data->tgl_awal);
			xlsWriteLabel($tablebody, $kolombody++, $data->tgl_akhir);

			$tablebody++;
			$nourut++;
		}

		xlsEOF();
		exit();
	}

	public function deteksi_tahun_ajaran($tgl_awal, $tgl_akhir, $type = 1, $tahun_ajaran_id = 'null') //sengaja dijadikan string coz it works
	{
		$getarrayoftahunajarantable = $this->Tahun_ajaran_model->get_all_except($tahun_ajaran_id);

		print_r($getarrayoftahunajarantable);

		$newdata = [
			'tgl_awal' => $tgl_awal,
			'tgl_akhir' => $tgl_akhir
		];

		print_r($newdata);

		$allowed = true;

		$tglawaldatabaru = date('Y-m-d', strtotime($newdata['tgl_awal']));
		$tglakhirdatabaru = date('Y-m-d', strtotime($newdata['tgl_akhir']));

		// check multidate between dates
		// foreach ($getarrayoftahunajarantable as $key => $value) {
		// 	$tglawaljadwalini = date('Y-m-d', strtotime($value['tgl_awal']));
		// 	$tglakhirjadwalini = date('Y-m-d', strtotime($value['tgl_akhir']));

		// 	if (($tglawaljadwalini >= $tglawaldatabaru && $tglawaljadwalini <= $tglakhirdatabaru) || ($tglakhirjadwalini >= $tglawaldatabaru && $tglakhirjadwalini <= $tglakhirdatabaru)) {
		// 		$allowed = false;
		// 		break;
		// 	}
		// }

		if ($type == 1) {
			echo json_encode([
				'allowed' => $allowed
			]);
		} else {
			return $allowed;
		}
	}

	public function playground()
	{
		echo '<pre>';
		$arrayjadwalmakanenak = [
            0 => [
                'nama_makanan' => 'Nasi Goreng Kambink',
                'range_tgl_awal_makan_allowed' => '2022-02-01',
                'range_tgl_akhir_makan_allowed' => '2023-02-04'
            ],
        ];

		print_r($arrayjadwalmakanenak);

        $newdata = [
            'nama_makanan' => 'Indomie 5 Bungkus GORENG PEDAAAAAAAASSS',
            'range_tgl_awal_makan_allowed' => '2022-01-01',
            'range_tgl_akhir_makan_allowed' => '2022-01-29'
        ];

        $message = '';
        $allowed = true;
        $tglawaljadwalmakanbaru = date('Y-m-d', strtotime($newdata['range_tgl_awal_makan_allowed']));
        $tglakhirjadwalmakanbaru = date('Y-m-d', strtotime($newdata['range_tgl_akhir_makan_allowed']));

        foreach ($arrayjadwalmakanenak as $key => $value) {
            $tglawaljadwalmakan = date('Y-m-d', strtotime($value['range_tgl_awal_makan_allowed']));
            $tglakhirjadwalmakan = date('Y-m-d', strtotime($value['range_tgl_akhir_makan_allowed']));
            

            if ($tglakhirjadwalmakanbaru < $tglawaljadwalmakanbaru){
              $allowed = false;
              $message = 'tgl akhir tidak boleh kurang dari tanggal awal';
              break;
            } 

            if ($tglawaljadwalmakanbaru <= $tglakhirjadwalmakan ) {
                $allowed = false;
                $message = 'WOI, JANGAN MAKAN ENAK DI TANGGAL '.$newdata['range_tgl_awal_makan_allowed'].' - '.$newdata['range_tgl_akhir_makan_allowed'].', MAKAN ENAK KM UDAH TERJADWAL DI TANGGAL SEGITU!!!! >:(';
                break;
            }   
        }

        if ($allowed) {
            array_push($arrayjadwalmakanenak, $newdata);
            $message = 'QM BOLEH MAKAN ENAK DI TANGGAL SEGITUU :)';
        }

		echo $message;

		print_r($arrayjadwalmakanenak);

		echo '</pre>';
	}
}

/* End of file Tahun_ajaran.php */
/* Location: ./application/controllers/Tahun_ajaran.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2022-02-01 06:16:55 */
/* http://harviacode.com */
