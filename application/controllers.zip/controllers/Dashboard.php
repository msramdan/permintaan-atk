<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jayapura');
class Dashboard extends CI_Controller {

	function __construct()
    {
        parent::__construct();
        is_login();
		check_admin();
		$this->load->model('App_setting_model');
    }

	public function index()
	{
		$data = array(
            'sett_apps' =>$this->App_setting_model->get_by_id(1),
			'classnyak' => $this
        );
		$this->template->load('template','dashboard',$data);
	}

	public function get_average_time($date, $tipe, $jenisjam = 'jam_masuk')
	{
		$query = "
			SELECT 
				SEC_TO_TIME(AVG(TIME_TO_SEC(`".$jenisjam."`))) as 'avg' 
			FROM absen 
			JOIN user ON user.user_id=absen.user_id
			WHERE DATE(tanggal) = '".$date."' AND level_id = ".$tipe.";
		";
		$data = $this->db->query($query)->row()->avg;
		if($data) {
			return substr($data, 0, -8);
		} else {
			return 'N/A';
		}
	}

	public function get_average_time_list($jenisjam)
	{
		$str = '';
		for ($i = 0; $i < 5; $i++) {
			$date = date('Y-m-d', strtotime('-' . $i . ' days'));

			$stylny = '';
			if($i == 0){
				
				$stylny = 'style="font-size: 15px; font-weight: bold; font-style: italic;"';
			}

			$str.='<tr '.$stylny.'>
					<td nowrap="">'.$date.'</td>
					<td>'.$this->get_average_time($date,4, $jenisjam).'</i></span></td>
					<td>'.$this->get_average_time($date,2, $jenisjam).'</i></span></td>
					<td>'.$this->get_average_time($date,3, $jenisjam).'</i></span></td>
				</tr>';
		}

		echo json_encode($str);
	}

	public function get_absensi_month()
	{
		// loop through this month
		$data = array(
			'bulan' => 03,
			'tahun' => date('Y'),
			'jumlah_masuk' => [],
			'jumlah_izin' => [],
			'jumlah_sakit' => [],
		);
		// max days in month
		$max_days = cal_days_in_month(CAL_GREGORIAN, $data['bulan'], $data['tahun']);


		for ($i = 1; $i <= $max_days; $i++) {

			$date = $data['tahun'].'-'.$data['bulan'].'-'.$i;
			$querymasuk = "
				SELECT 
					COUNT(*) as 'count' 
				FROM absen 
				WHERE DATE(tanggal) = '".$date."' AND keterangan = 'Masuk';
			";

			$queryizin = "
				SELECT 
					COUNT(*) as 'count' 
				FROM absen 
				WHERE DATE(tanggal) = '".$date."' AND keterangan = 'Izin';
			";

			$querysakit = "
				SELECT 
					COUNT(*) as 'count' 
				FROM absen 
				WHERE DATE(tanggal) = '".$date."' AND keterangan = 'Sakit';
			";
			// push to $data > jumlah_masuk
			array_push($data['jumlah_masuk'], $this->db->query($querymasuk)->row()->count);
			array_push($data['jumlah_izin'], $this->db->query($queryizin)->row()->count);
			array_push($data['jumlah_sakit'], $this->db->query($querysakit)->row()->count);
			
		}
		echo json_encode($data);
	}

	public function jumlah_status_absensi()
	{
		$arr = [
			'masuk' => [0,''],
			'izin' => [0,''],
			'sakit' => [0,''],
			'alpa' => [0,''],
			'total' => [0,'']
		];

		foreach ($arr as $key => $value) {
			$query = "
				SELECT 
					COUNT(*) as 'count' 
				FROM absen 
				WHERE keterangan = '".strtoupper($key)."' AND DATE(tanggal) = '".date('Y-m-d')."';";
			$arr[$key][0] = $this->db->query($query)->row()->count;
		}

		$totalguru = $this->db->query("SELECT COUNT(*) as 'count' FROM guru")->row()->count;
		$totalpegawai = $this->db->query("SELECT COUNT(*) as 'count' FROM pegawai")->row()->count;
		$totalsiswa = $this->db->query("SELECT COUNT(*) as 'count' FROM siswa")->row()->count;

		$totalseluruhny = $totalguru + $totalpegawai + $totalsiswa;

		$total = 0;
		foreach ($arr as $key => $value) {
			$total += $value[0];
		}
		$arr['total'][0] = $total;
		$arr['total'][1] = '100%';

		$arr['alpa'][0] = $totalseluruhny - $total;

		$totalseluruhgurupegawaisiswa = $this->db->query("SELECT COUNT(*) as 'count' FROM user WHERE level_id IN (1,2,3,4)")->row()->count;

		foreach ($arr as $key => $value) {

			if($totalseluruhgurupegawaisiswa == 0) {
				$totalseluruhgurupegawaisiswa = 1;
			}

			$arr[$key][1] = round($value[0] / $totalseluruhgurupegawaisiswa * 100,2)."%";
		}

		echo json_encode($arr);
	}
}
