<?php

if (!defined('BASEPATH'))
exit('No direct script access allowed');

// header('Access-Control-Allow-Origin: *');

// header('Access-Control-Allow-Methods: GET, POST');

// header("Access-Control-Allow-Headers: X-Requested-With");

class Izin_sakit extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		is_login();

		$this->load->model('Izin_sakit_model');
		$this->load->model('App_setting_model');
		$this->load->model('Absen_model');
		$this->load->model('User_model');
		$this->load->library('form_validation');
	}

	public function index()
	{
		check_admin();
		$izin_sakit = $this->Izin_sakit_model->get_all();
		$data = array(
			'izin_sakit_data' => $izin_sakit,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('template', 'izin_sakit/izin_sakit_list', $data);
	}

	public function read($id)
	{
		check_admin();
		$row = $this->Izin_sakit_model->get_by_id(decrypt_url($id));
		if ($row) {
			$data = array(
				'izin_sakit_id' => $row->izin_sakit_id,
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'user_id' => $row->user_id,
				'tanggal' => $row->tanggal,
				'photo' => $row->photo,
				'keterangan' => $row->keterangan,
				'status' => $row->status,
				'deskripsi' => $row->deskripsi,
			);
			$this->template->load('template', 'izin_sakit/izin_sakit_read', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('izin_sakit'));
		}
	}

	public function create()
	{
		check_admin();
		$user = $this->User_model->get_all_ex_admin();
		$data = array(
			'button' => 'Create',
			'user_data' => $user,
			'action' => site_url('izin_sakit/create_action'),
			'izin_sakit_id' => set_value('izin_sakit_id'),
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'user_id' => set_value('user_id'),
			'photo' => set_value('photo'),
			'tanggal' => set_value('tanggal'),
			'tanggal_lama' => set_value('tanggal'),
			'keterangan' => set_value('keterangan'),
			'status' => set_value('status'),
			'deskripsi' => set_value('deskripsi'),
		);
		$this->template->load('template', 'izin_sakit/izin_sakit_form', $data);
	}

	public function create_action()
	{
		check_admin();
		$this->_rules();
		if ($this->form_validation->run() == FALSE) {
			$this->create();
		} else {
			$user = $this->input->post('user_id');
			$tanggal = $this->input->post('tanggal');

			$tanggal_hari_ini = $this->input->post('tanggal');
			$day = date('l', strtotime($tanggal));
			$cek_hari_libur = hari_libur($this->input->post('tanggal'));

			$query = $this->db->query("SELECT * FROM izin_sakit where tanggal='$tanggal' and user_id='$user'");
			$jml = $query->num_rows();
			if ($jml > 0) {
				$this->session->set_flashdata('error', 'Sudah ada data pada hari tersebut');
				redirect(site_url('Izin_sakit'));
			} else if ($day == 'Sunday') {
				$this->session->set_flashdata('error', 'Tidak bisa pengajuan izin/sakit hari minggu');
				redirect(site_url('Izin_sakit'));
			} else if ($cek_hari_libur == true) {
				$this->session->set_flashdata('error', 'Tidak bisa pengajuan izin/sakit hari libur');
				redirect(site_url('Izin_sakit'));
			} else {
				$config['upload_path']      = './assets/assets/img/izin';
				$config['allowed_types']    = 'jpg|png|jpeg|pdf|doc|docx';
				$config['max_size']         = 10048;
				$config['file_name']        = 'File-' . date('ymd') . '-' . substr(sha1(rand()), 0, 10);
				$this->load->library('upload', $config);
				$this->upload->initialize($config);
				$this->upload->do_upload("photo");
				$data = $this->upload->data();
				$photo = $data['file_name'];

				$data = array(
					'user_id' => $this->input->post('user_id', TRUE),
					'photo' => $photo,
					'keterangan' => $this->input->post('keterangan', TRUE),
					'tanggal' => $this->input->post('tanggal', TRUE),
					'status' => 'Waiting',
					'deskripsi' => $this->input->post('deskripsi', TRUE),
				);
				$this->Izin_sakit_model->insert($data);
				$this->session->set_flashdata('message', 'Create Record Success');
				redirect(site_url('izin_sakit'));
			}
		}
	}

	public function update($id)
	{
		check_admin();
		$user = $this->User_model->get_all_ex_admin();
		$row = $this->Izin_sakit_model->get_by_id(decrypt_url($id));
		if ($row) {
			$data = array(
				'button' => 'Update',
				'user_data' => $user,
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'action' => site_url('izin_sakit/update_action'),
				'izin_sakit_id' => set_value('izin_sakit_id', $row->izin_sakit_id),
				'user_id' => set_value('user_id', $row->user_id),
				'photo' => set_value('photo', $row->photo),
				'tanggal' => set_value('tanggal', $row->tanggal),
				'tanggal_lama' => $row->tanggal,
				'keterangan' => set_value('keterangan', $row->keterangan),
				'status' => set_value('status', $row->status),
				'deskripsi' => set_value('deskripsi', $row->deskripsi),
			);
			$this->template->load('template', 'izin_sakit/izin_sakit_form', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('izin_sakit'));
		}
	}

	public function update_action()
	{
		check_admin();
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->update(encrypt_url($this->input->post('izin_sakit_id')));
		} else {
			$user = $this->input->post('user_id');
			$tanggal = $this->input->post('tanggal');
			$tanggal_lama = $this->input->post('tanggal_lama');
			if ($tanggal == $tanggal_lama) {
				$jml = 0;
			} else {
				$query = $this->db->query("SELECT * FROM izin_sakit where tanggal='$tanggal' and user_id='$user'");
				$jml = $query->num_rows();
			}
			if ($jml > 0) {
				$this->session->set_flashdata('error', 'Sudah ada data pada hari tersebut');
				redirect(site_url('izin_sakit'));
			} else {
				// untuk uplaod photo
				$config['upload_path']      = './assets/assets/img/izin';
				$config['allowed_types']    = 'jpg|png|jpeg';
				$config['max_size']         = 10048;
				$config['file_name']        = 'File-' . date('ymd') . '-' . substr(sha1(rand()), 0, 10);
				$this->load->library('upload', $config);
				$this->upload->initialize($config);
				if ($this->upload->do_upload("photo")) {
					$id = $this->input->post('izin_sakit_id');
					$row = $this->Izin_sakit_model->get_by_id($id);
					$data = $this->upload->data();
					$photo = $data['file_name'];
					if ($row->photo == null || $row->photo == '') {
					} else {
						$target_file = './assets/assets/img/izin/' . $row->photo;
						unlink($target_file);
					}
				} else {
					$photo = $this->input->post('photo_lama');
				}
				$data = array(
					'user_id' => $this->input->post('user_id', TRUE),
					'tanggal' => $this->input->post('tanggal', TRUE),
					'photo' => $photo,
					'keterangan' => $this->input->post('keterangan', TRUE),
					'deskripsi' => $this->input->post('deskripsi', TRUE),
				);

				$this->Izin_sakit_model->update($this->input->post('izin_sakit_id', TRUE), $data);
				$this->session->set_flashdata('message', 'Update Record Success');
				redirect(site_url('izin_sakit'));
			}
		}
	}

	public function delete($id)
	{
		check_admin();
		$row = $this->Izin_sakit_model->get_by_id(decrypt_url($id));
		if ($row) {
			if ($row->photo == null || $row->photo == '') {
			} else {
				$target_file = './assets/assets/img/izin/' . $row->photo;
				unlink($target_file);
			}

			$this->Izin_sakit_model->delete(decrypt_url($id));
			$this->session->set_flashdata('message', 'Delete Record Success');
			redirect(site_url('izin_sakit'));
		} else {
			$this->session->set_flashdata('error', 'Record Not Found');
			redirect(site_url('izin_sakit'));
		}
	}

	public function _rules()
	{
		$this->form_validation->set_rules('user_id', 'user id', 'trim|required');
		$this->form_validation->set_rules('photo', 'photo', 'trim');
		$this->form_validation->set_rules('keterangan', 'keterangan', 'trim|required');
		$this->form_validation->set_rules('tanggal', 'Tanggal', 'trim|required');
		$this->form_validation->set_rules('deskripsi', 'deskripsi', 'trim|required');

		$this->form_validation->set_rules('izin_sakit_id', 'izin_sakit_id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
	}

	public function excel()
	{
		check_admin();
		$this->load->helper('exportexcel');
		$namaFile = "izin_sakit.xls";
		$judul = "izin_sakit";
		$tablehead = 0;
		$tablebody = 1;
		$nourut = 1;
		//penulisan header
		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");
		header("Content-Disposition: attachment;filename=" . $namaFile . "");
		header("Content-Transfer-Encoding: binary ");

		xlsBOF();

		$kolomhead = 0;
		xlsWriteLabel($tablehead, $kolomhead++, "No");
		xlsWriteLabel($tablehead, $kolomhead++, "User Id");
		xlsWriteLabel($tablehead, $kolomhead++, "Photo");
		xlsWriteLabel($tablehead, $kolomhead++, "Keterangan");
		xlsWriteLabel($tablehead, $kolomhead++, "Status");
		xlsWriteLabel($tablehead, $kolomhead++, "Deskripsi");

		foreach ($this->Izin_sakit_model->get_all() as $data) {
			$kolombody = 0;

			//ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
			xlsWriteNumber($tablebody, $kolombody++, $nourut);
			xlsWriteNumber($tablebody, $kolombody++, $data->user_id);
			xlsWriteLabel($tablebody, $kolombody++, $data->photo);
			xlsWriteLabel($tablebody, $kolombody++, $data->keterangan);
			xlsWriteLabel($tablebody, $kolombody++, $data->status);
			xlsWriteLabel($tablebody, $kolombody++, $data->deskripsi);

			$tablebody++;
			$nourut++;
		}

		xlsEOF();
		exit();
	}

	public function download($gambar)
	{
		check_admin();
		force_download('assets/assets/img/izin/' . $gambar, NULL);
	}

	public function update_status()
	
	{
	    
		check_admin();
		$izin_sakit_id  = $this->input->post('izin_sakit_id');
		$status = $this->input->post('status');
		$row = $this->Izin_sakit_model->get_by_id($izin_sakit_id);
		$query = $this->db->query("SELECT * FROM absen where tanggal='$row->tanggal' and user_id='$row->user_id'");
		$jml = $query->num_rows();
		$nama_siswa = nama_siswa($row->user_id);
		$no_hp = no_hp_wali($row->user_id);
		$fix_no = $no_hp;

		if ($jml > 0) {
			$this->session->set_flashdata('error', 'Sudah ada data tanggal tersebut');
		} else {
			if ($status == 'Approved') {
				$data = array(
					'user_id' => $row->user_id,
					'tanggal' => $row->tanggal,
					'keterangan' => $row->keterangan,
				);
				$this->db->insert('absen', $data);
			}
			$data2 = array(
				'status' => $status
			);
			$this->db->where('izin_sakit_id ', $izin_sakit_id);
			$this->db->update('izin_sakit', $data2);

			// kirim pesan wa
			$cek_dlu = $this->App_setting_model->get_by_id(1);
			$is = $cek_dlu->wa_blast;
			if($is =='Aktif'){
				if ($this->db->affected_rows() > 0) {
					$url = 'http://:8080/v2/send-message';
					$ch = curl_init($url);
					
					if ($status == 'Approved') {
						$data = array(
							'number' => $fix_no,
							'message' =>'Assalamualaikum Wr Wb Bapak/Ibu wali murid, Ananda ' . $nama_siswa . ', Pengajuan surat ' . $row->keterangan . ', Tanggal ' . $row->tanggal . ' di Setujui oleh Admin, Terimakasih !!!'
						);
					} else {
						$data = array(
							'number' => $fix_no,
							'message' => 'Assalamualaikum Wr Wb Bapak/Ibu wali murid, Ananda ' . $nama_siswa . ', Pengajuan surat ' . $row->keterangan . ', Tanggal ' . $row->tanggal . ' di Tolak oleh Admin, Terimakasih !!!'
						);
					}
					$payload = json_encode($data);
					curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
					curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					curl_exec($ch);
					curl_close($ch);
				}
			}


			
			$this->session->set_flashdata('message', 'Data Terupdate');
		}
		redirect('izin_sakit');
	}

	public function detail_siswa()
	{
		$user_id = $this->input->post('user_id');
		$data = $this->db->query("SELECT * FROM izin_sakit join user on user.user_id=izin_sakit.user_id
							join siswa on siswa.nisn = user.username
							join kelas on kelas.kelas_id = siswa.kelas_id
							where user.user_id='$user_id'")->row_array();
		Header('Content-Type: application/json');
		echo json_encode($data);
	}
}
