<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Surat_panggilan extends CI_Controller {

	function __construct()
    {
        parent::__construct();
        is_login();
		check_admin();
		$this->load->model('App_setting_model');
		$this->load->model('Siswa_model');
    }

	public function index()
	{
		$whereto = $this->input->get('page');

		if($whereto == 'list') {
			$this->list();
		}

		if($whereto == 'history') {
			$this->history();
		}

		if($whereto == null) {
			redirect(site_url('surat_panggilan?page=list'));
		}
	}

	public function generate()
	{
		$siswa_id = decrypt_url($this->input->post('id_siswa'));

		$getdatasiswa = $this->Siswa_model->get_by_id($siswa_id);

		$tgl_dipanggil = date('Y-m-d', strtotime($this->input->post('tanggal_dipanggil')));
		
		$data = array(
			'tgl_panggil_wali' => $tgl_dipanggil
		);
		$this->Siswa_model->update($siswa_id, $data);

		$textsurat = "Telah terlambat sebanyak <b>".$this->input->post('telat')."x</b> dan tidak hadir selama <b>".$this->input->post('tidakhadir')."x</b>";

		$data = array(
			'nisn' => $getdatasiswa->nisn,
			'siswa_id' => $siswa_id,
			'terakhir_dipanggil' => $tgl_dipanggil,
			'keterangan' => $textsurat,
			'status_sp' => 0,
		);

		$this->db->insert('surat_panggilan', $data);

		$status = '';
		$message = '';
		
		if($this->db->affected_rows() > 0) {
			$status = 'success';
			$message = 'Surat panggilan berhasil dibuat';
		} else {
			$status = 'error';
			$message = 'Surat panggilan gagal dibuat';
		}

		$id_surat_panggilan = $this->db->insert_id();

		$resp = array(
			'status' => $status,
			'message' => $message,
			'id_surat' => $id_surat_panggilan
		);

		echo json_encode($resp);
	}

	public function list()
	{
		$data = array(
            'sett_apps' =>$this->App_setting_model->get_by_id(1),
			'siswa_data' => $this->Siswa_model->get_all(),
        );
		$this->template->load('template','surat_panggilan/surat_panggilan_list',$data);
	}

	public function history()
	{
		// select all data from table surat_panggilan
		$data = array(
			'sett_apps' =>$this->App_setting_model->get_by_id(1),
			'surat_panggilan_data' => $this->db->query("
				SELECT * FROM surat_panggilan
				JOIN siswa ON siswa.nisn = surat_panggilan.nisn
				JOIN kelas ON kelas.kelas_id = siswa.kelas_id
				ORDER BY id_surat_panggilan DESC
			")->result(),
		);
		$this->template->load('template','surat_panggilan/surat_panggilan_history',$data);
	}

	public function update_status_sp($a)
	{
		$id_surat_panggilan = decrypt_url($a);

		$data = array(
			'status_sp' => 1
		);

		$this->db->where('id_surat_panggilan', $id_surat_panggilan);
		$this->db->update('surat_panggilan', $data);

		$status = '';
		$message = '';
		
		if($this->db->affected_rows() > 0) {
			$status = 'success';
			$message = 'Surat panggilan berhasil diselesaikan';
		} else {
			$status = 'error';
			$message = 'Surat panggilan gagal diselesaikan';
		}

		// session
		$this->session->set_flashdata('message', $message);
		redirect(site_url('surat_panggilan?page=history'));
	}



}
