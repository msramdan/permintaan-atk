<?php

if (!defined('BASEPATH'))
exit('No direct script access allowed');
date_default_timezone_set('Asia/Jayapura');

class Halaman_absensi extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		is_login();
		$this->load->model('Halaman_absensi_model');
		$this->load->model('App_setting_model');
		$this->load->library('form_validation');
	}


	public function update($id)
	{
		$row = $this->Halaman_absensi_model->get_by_id(decrypt_url($id));

		if ($row) {
			$data = array(
				'button' => 'Update',
				'action' => site_url('halaman_absensi/update_action'),
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'halaman_absensi_id' => set_value('halaman_absensi_id', $row->halaman_absensi_id),
				'is_aktif' => set_value('is_aktif', $row->is_aktif),
				'password_lock_screen' => set_value('password_lock_screen', $row->password_lock_screen),
			);
			$this->template->load('template', 'halaman_absensi/halaman_absensi_form', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('halaman_absensi/update/'.encrypt_url(1)));
		}
	}

	public function update_action()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->update(encrypt_url($this->input->post('halaman_absensi_id')));
		} else {

			if ($this->input->post('password_lock_screen') == '' || $this->input->post('password_lock_screen') == null) {
				$data = array(
					'is_aktif' => $this->input->post('is_aktif', TRUE),
				);
			} else {
				$data = array(
					'is_aktif' => $this->input->post('is_aktif', TRUE),
					'password_lock_screen' => sha1($this->input->post('password_lock_screen', TRUE)),
				);
			}

			$this->Halaman_absensi_model->update($this->input->post('halaman_absensi_id', TRUE), $data);
			$this->session->set_flashdata('message', 'Update Record Success');
			redirect(site_url('halaman_absensi/update/'.encrypt_url(1)));
		}
	}

	public function _rules()
	{
		$this->form_validation->set_rules('is_aktif', 'is aktif', 'trim|required');
		$this->form_validation->set_rules('password_lock_screen', 'password lock screen', 'trim');
		$this->form_validation->set_rules('halaman_absensi_id', 'halaman_absensi_id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
	}
}

