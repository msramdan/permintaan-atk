<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Laporan extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('App_setting_model');
		$this->load->model('User_model');
		$this->load->model('Kelas_model');
		$this->load->library('form_validation');
	}

	public function laporan_guru()
	{
		$query = $this->db->query("SELECT YEAR(tanggal) as tahun from absen GROUP BY YEAR(tanggal)");
		$user = $this->User_model->get_all_ex_admin(2);
		$data = array(
			'button' => 'Create',
			'tahun_data' => $query->result(),
			'user_data' => $user,
			'level_id' => 2,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'action' => site_url('laporan/view_laporan_guru'),
			'user_id' => set_value('user_id'),
			'bulan' => set_value('bulan'),
			'tahun' => set_value('tahun'),
		);
		$this->template->load('template', 'laporan/laporan_guru', $data);
	}

	public function laporan_pegawai()
	{
		$query = $this->db->query("SELECT YEAR(tanggal) as tahun from absen GROUP BY YEAR(tanggal)");
		$user = $this->User_model->get_all_ex_admin(3);
		$data = array(
			'button' => 'Create',
			'tahun_data' => $query->result(),
			'user_data' => $user,
			'level_id' => 2,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'action' => site_url('laporan/view_laporan_pegawai'),
			'user_id' => set_value('user_id'),
			'bulan' => set_value('bulan'),
			'tahun' => set_value('tahun'),
		);
		$this->template->load('template', 'laporan/laporan_pegawai', $data);
	}

	public function laporan_siswa()
	{
		$query = $this->db->query("SELECT YEAR(tanggal) as tahun from absen GROUP BY YEAR(tanggal)");
		$user = $this->User_model->get_all_ex_admin(4);
		$kelas = $this->Kelas_model->get_all();
		$data = array(
			'button' => 'Create',
			'tahun_data' => $query->result(),
			'user_data' => $user,
			'level_id' => 2,
			'kelas' => $kelas,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'action' => site_url('laporan/view_laporan_siswa'),
			'user_id' => set_value('user_id'),
			'kelas_id' => set_value('kelas_id'),
			'bulan' => set_value('bulan'),
			'tahun' => set_value('tahun'),
		);
		$this->template->load('template', 'laporan/laporan_siswa', $data);
	}
	public function view_laporan_guru()
	{
		$this->_rules();
		if ($this->form_validation->run() == FALSE) {
			$this->laporan_guru();
		} else {
			$data = array(
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'user_id' => $this->input->post('user_id', TRUE),
				'bulan' => $this->input->post('bulan', TRUE),
				'tahun' => $this->input->post('tahun', TRUE),
				'area' => 'guru'
			);
			$this->template->load('template', 'laporan/view_laporan_guru', $data);
		}
	}

	public function view_laporan_pegawai()
	{

		$this->_rules();
		if ($this->form_validation->run() == FALSE) {
			$this->laporan_pegawai();
		} else {
			$data = array(
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'user_id' => $this->input->post('user_id', TRUE),
				'bulan' => $this->input->post('bulan', TRUE),
				'tahun' => $this->input->post('tahun', TRUE),
				'area' => 'pegawai'
			);
			$this->template->load('template', 'laporan/view_laporan_pegawai', $data);
		}
	}

	public function view_laporan_siswa()
	{
			$data = array(
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'user_id' => $this->input->post('user_id', TRUE),
				'kelas_id' => $this->input->post('kelas_id', TRUE),
				'bulan' => $this->input->post('bulan', TRUE),
				'tahun' => $this->input->post('tahun', TRUE),
				'area' => 'siswa'
			);
			$this->template->load('template', 'laporan/view_laporan_siswa', $data);
	}

	public function _rules()
	{
		$this->form_validation->set_rules('bulan', 'Bulan', 'trim|required');
		$this->form_validation->set_rules('tahun', 'Tahun', 'trim|required');
		$this->form_validation->set_rules('user_id', 'User', 'trim|required');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
	}
	function get_data_siswa()
	{
		$id = $this->input->post('selectedValue');
		$output = '';
		$kelas_data = $this->db->query("SELECT siswa.*,user.* from siswa join user on user.username = siswa.nisn where siswa.kelas_id='$id'")->result();
		$query_cek = $this->db->query("SELECT siswa.*,user.* from siswa join user on user.username = siswa.nisn where siswa.kelas_id='$id'");
		$jml = $query_cek->num_rows();

		if ($id == null || $id == '') {
			$output .= '
				Silahkan pilih Kelas terlebih dahulu';
		} else {
			if ($jml > 0) {
				$output .= '
				<select name="user_id" class="form-control theSelect">
				<option style="color: black; border-color:grey" value="">-- Pilih -- </option>
				<option style="color: black; border-color:grey" value="semua_data">-- Semua Siswa -- </option>';
				foreach ($kelas_data as $row) {
					$output .= ' <option style="color: black; border-color:grey" value="' . $row->user_id . '">' . $row->nama_siswa . '</option>
				  ';
				}
				$output .= '</select>';
			} else {
				$output .= '<select class="form-control" name="" id="" required><option value="">-- Pilih -- </option>';
				$output .= '</select>
				<p style="color:white">Tidak ada siswa di kelas ini, Silahkan pilih kelas lain untuk lihat laporan</p>';
			}
		}
		echo $output;
	}
}
