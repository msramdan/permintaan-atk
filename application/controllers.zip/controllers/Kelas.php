<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Kelas extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		is_login();
		check_admin();
		$this->load->model('Kelas_model');
		$this->load->model('Jenjang_model');
		$this->load->model('App_setting_model');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$kelas = $this->Kelas_model->get_all();
		$data = array(
			'kelas_data' => $kelas,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('template', 'kelas/kelas_list', $data);
	}


	public function create()
	{
		$data = array(
			'button' => 'Create',
			'jenjang' => $this->Jenjang_model->get_all(),
			'action' => site_url('kelas/create_action'),
			'kelas_id' => set_value('kelas_id'),
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'jenjang_id' => set_value('jenjang_id'),
			'nama_kelas' => set_value('nama_kelas'),
			'walikelas' => set_value('walikelas'),
		);
		$this->template->load('template', 'kelas/kelas_form', $data);
	}

	public function create_action()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->create();
		} else {
			$data = array(
				'jenjang_id' => $this->input->post('jenjang_id', TRUE),
				'nama_kelas' => $this->input->post('nama_kelas', TRUE),
				'walikelas' => $this->input->post('walikelas', TRUE),
			);

			$this->Kelas_model->insert($data);
			$this->session->set_flashdata('message', 'Create Record Success');
			redirect(site_url('kelas'));
		}
	}

	public function update($id)
	{
		$row = $this->Kelas_model->get_by_id(decrypt_url($id));

		if ($row) {
			$data = array(
				'button' => 'Update',
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'jenjang' => $this->Jenjang_model->get_all(),
				'action' => site_url('kelas/update_action'),
				'kelas_id' => set_value('kelas_id', $row->kelas_id),
				'jenjang_id' => set_value('jenjang_id', $row->jenjang_id),
				'nama_kelas' => set_value('nama_kelas', $row->nama_kelas),
				'walikelas' => set_value('walikelas', $row->walikelas),
			);
			$this->template->load('template', 'kelas/kelas_form', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('kelas'));
		}
	}

	public function update_action()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->update(encrypt_url($this->input->post('kelas_id')));
		} else {
			$data = array(
				'jenjang_id' => $this->input->post('jenjang_id', TRUE),

				'nama_kelas' => $this->input->post('nama_kelas', TRUE),
				'walikelas' => $this->input->post('walikelas', TRUE),
			);

			$this->Kelas_model->update($this->input->post('kelas_id', TRUE), $data);
			$this->session->set_flashdata('message', 'Update Record Success');
			redirect(site_url('kelas'));
		}
	}

	public function delete($id)
	{
		$row = $this->Kelas_model->get_by_id(decrypt_url($id));

		if ($row) {
			$this->Kelas_model->delete(decrypt_url($id));
			$error = $this->db->error();
			if ($error['code'] != 0) {
				$this->session->set_flashdata('error', 'Tidak dapat dihapus data sudah berrelasi');
			} else {
				$this->session->set_flashdata('message', 'Delete Record Success');
			}
			redirect(site_url('kelas'));
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('kelas'));
		}
	}

	public function _rules()
	{
		$this->form_validation->set_rules('jenjang_id', 'jenjang id', 'trim|required');
		$this->form_validation->set_rules('nama_kelas', 'nama kelas', 'trim|required');
		$this->form_validation->set_rules('walikelas', 'Walikelas', 'trim|required');
		$this->form_validation->set_rules('kelas_id', 'kelas_id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
	}

	public function excel()
	{
		$this->load->helper('exportexcel');
		$namaFile = "kelas.xls";
		$judul = "kelas";
		$tablehead = 0;
		$tablebody = 1;
		$nourut = 1;
		//penulisan header
		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");
		header("Content-Disposition: attachment;filename=" . $namaFile . "");
		header("Content-Transfer-Encoding: binary ");

		xlsBOF();

		$kolomhead = 0;
		xlsWriteLabel($tablehead, $kolomhead++, "No");
		xlsWriteLabel($tablehead, $kolomhead++, "Jenjang Id");
		xlsWriteLabel($tablehead, $kolomhead++, "Nama Kelas");

		foreach ($this->Kelas_model->get_all() as $data) {
			$kolombody = 0;

			//ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
			xlsWriteNumber($tablebody, $kolombody++, $nourut);
			xlsWriteNumber($tablebody, $kolombody++, $data->jenjang_id);
			xlsWriteLabel($tablebody, $kolombody++, $data->nama_kelas);

			$tablebody++;
			$nourut++;
		}

		xlsEOF();
		exit();
	}
}
