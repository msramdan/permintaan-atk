<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');
date_default_timezone_set('Asia/Jayapura');


header('Access-Control-Allow-Origin: *');

header('Access-Control-Allow-Methods: GET, POST');

header("Access-Control-Allow-Headers: X-Requested-With");

class Absen extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		is_login();
		$this->load->model('Absen_model');
		$this->load->model('User_model');
		$this->load->model('App_setting_model');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$absen = $this->Absen_model->get_all();
		$data = array(
			'absen_data' => $absen,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('template', 'absen/absen_list', $data);
	}

	public function guru()
	{
		$absen = $this->Absen_model->get_all(2);
		$data = array(
			'absen_data' => $absen,
			'level_id' => 2,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('template', 'absen/absen_list', $data);
	}

	public function pegawai()
	{
		$absen = $this->Absen_model->get_all(3);
		$data = array(
			'absen_data' => $absen,
			'level_id' => 3,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('template', 'absen/absen_list', $data);
	}

	public function siswa()
	{
		$absen = $this->Absen_model->get_all(4);
		$data = array(
			'absen_data' => $absen,
			'level_id' => 4,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('template', 'absen/absen_list', $data);
	}

	public function create($level_id = null)
	{
		$level_id = decrypt_url($level_id);
		$user = $this->User_model->get_all_ex_admin($level_id);
		$data = array(
			'button' => 'Create',
			'user_data' => $user,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'action' => site_url('absen/create_action'),
			'absen_id' => set_value('absen_id'),
			'user_id' => set_value('user_id'),
			'tanggal' => set_value('tanggal'),
			'tanggal_lama' => set_value('tanggal'),
			'jam_masuk' => set_value('jam_masuk'),
			'jam_pulang' => set_value('jam_pulang'),
			// 'status_masuk' => set_value('status_masuk'),
		);
		$this->template->load('template', 'absen/absen_form', $data);
	}

	public function create_action()
	{
		$level_id = $this->input->post('level_id');
		$tgl = $this->input->post('tanggal');
		$cek_hari  = date('D', strtotime($tgl));
		switch ($cek_hari) {
			case 'Sun':
				$hari_ini = "Minggu";
				break;
			case 'Mon':
				$hari_ini = "Senin";
				break;

			case 'Tue':
				$hari_ini = "Selasa";
				break;

			case 'Wed':
				$hari_ini = "Rabu";
				break;

			case 'Thu':
				$hari_ini = "Kamis";
				break;

			case 'Fri':
				$hari_ini = "Jumat";
				break;

			case 'Sat':
				$hari_ini = "Sabtu";
				break;

			default:
				$hari_ini = "Tidak di ketahui";
				break;
		}

		$data = $this->db->query("SELECT * FROM waktu_absen where nama_hari='$hari_ini'")->row();
		if ($level_id == 2) {
			$late_waktu_absen = $data->jam_masuk_guru;
			$minutes_to_add = $data->absen_terlambat_guru;
		} else if ($level_id == 3) {
			$late_waktu_absen = $data->jam_masuk_guru;
			$minutes_to_add = $data->absen_terlambat_guru;
		} else if ($level_id == 4) {
			$late_waktu_absen = $data->jam_masuk_siswa;
			$minutes_to_add = $data->absen_terlambat_siswa;
		}
		$time = new DateTime($late_waktu_absen);
		$time->add(new DateInterval('PT' . $minutes_to_add . 'M'));
		$stamp = $time->format('H:i');
		$now = $this->input->post('jam_masuk');

		if ($now > $stamp) {
			$status = 'Terlambat';
		} else {
			$status = 'Tepat Waktu';
		}


		$this->_rules();
		if ($this->form_validation->run() == FALSE) {
			$this->create(encrypt_url($level_id));
		} else {
			$user = $this->input->post('user_id');
			$tanggal = $this->input->post('tanggal');
			$query = $this->db->query("SELECT * FROM absen where tanggal='$tanggal' and user_id='$user'");
			$jml = $query->num_rows();
			if ($jml > 0) {
				$this->session->set_flashdata('error', 'Sudah ada data pada hari tersebut');
				if ($level_id == 2) {
					redirect(site_url('absen/guru'));
				} else if ($level_id == 3) {
					redirect(site_url('absen/pegawai'));
				} else if ($level_id == 4) {
					redirect(site_url('absen/siswa'));
				}
			} else {
				$data = array(
					'user_id' => $this->input->post('user_id', TRUE),
					'tanggal' => $this->input->post('tanggal', TRUE),
					'jam_masuk' => $this->input->post('jam_masuk', TRUE),
					'jam_pulang' => $this->input->post('jam_pulang', TRUE),
					'status_masuk' => $status,
					'keterangan' => 'Masuk',
				);
				$this->Absen_model->insert($data);

				if ($level_id == 4) {
					$no_hp = no_hp_wali($this->input->post('user_id'));
					$fix_no = $no_hp . '@c.us';
					$nama_siswa = nama_siswa($this->input->post('user_id'));

					// kirim pesan wa
					$cek_dlu = $this->App_setting_model->get_by_id(1);
					$is = $cek_dlu->wa_blast;
					if ($is == 'Aktif') {
						if ($this->db->affected_rows() > 0) {
							$url = 'http://';
							$ch = curl_init($url);
							$data = array(
								'number' => $fix_no,
								'message' => 'Assalamualaikum Wr Wb Bapak/Ibu wali murid, Ananda ' . $nama_siswa . ', Absen masuk tanggal ' . $this->input->post('tanggal') . ', pada jam ' . $this->input->post('jam_masuk') . ' status ' . $status . ', Terimakasih !!!'
							);
							$payload = json_encode($data);
							curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
							curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
							$result = curl_exec($ch);
							curl_close($ch);
						}
					}
				}

				$this->session->set_flashdata('message', 'Create Record Success');
				if ($level_id == 2) {
					redirect(site_url('absen/guru'));
				} else if ($level_id == 3) {
					redirect(site_url('absen/pegawai'));
				} else if ($level_id == 4) {
					redirect(site_url('absen/siswa'));
				}
			}
		}
	}

	public function update($id, $id_level)
	{
		$row = $this->Absen_model->get_by_id(decrypt_url($id));
		$level_id = decrypt_url($id_level);
		$user = $this->User_model->get_all_ex_admin($level_id);
		if ($row) {
			$data = array(
				'button' => 'Update',
				'user_data' => $user,
				'level_id' => $level_id,
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'action' => site_url('absen/update_action'),
				'tanggal_lama' => $row->tanggal,
				'absen_id' => set_value('absen_id', $row->absen_id),
				'user_id' => set_value('user_id', $row->user_id),
				'tanggal' => set_value('tanggal', $row->tanggal),
				'jam_masuk' => set_value('jam_masuk', $row->jam_masuk),
				'jam_pulang' => set_value('jam_pulang', $row->jam_pulang),
				// 'status_masuk' => set_value('status_masuk', $row->status),
			);
			$this->template->load('template', 'absen/absen_form', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('absen'));
		}
	}

	public function update_action()
	{
		$level_id = $this->input->post('level_id');
		$tgl = $this->input->post('tanggal');
		$cek_hari  = date('D', strtotime($tgl));
		switch ($cek_hari) {
			case 'Sun':
				$hari_ini = "Minggu";
				break;
			case 'Mon':
				$hari_ini = "Senin";
				break;

			case 'Tue':
				$hari_ini = "Selasa";
				break;

			case 'Wed':
				$hari_ini = "Rabu";
				break;

			case 'Thu':
				$hari_ini = "Kamis";
				break;

			case 'Fri':
				$hari_ini = "Jumat";
				break;

			case 'Sat':
				$hari_ini = "Sabtu";
				break;

			default:
				$hari_ini = "Tidak di ketahui";
				break;
		}

		$data = $this->db->query("SELECT * FROM waktu_absen where nama_hari='$hari_ini'")->row();
		if ($level_id == 2) {
			$late_waktu_absen = $data->jam_masuk_guru;
			$minutes_to_add = $data->absen_terlambat_guru;
		} else if ($level_id == 3) {
			$late_waktu_absen = $data->jam_masuk_guru;
			$minutes_to_add = $data->absen_terlambat_guru;
		} else if ($level_id == 4) {
			$late_waktu_absen = $data->jam_masuk_siswa;
			$minutes_to_add = $data->absen_terlambat_siswa;
		}
		$time = new DateTime($late_waktu_absen);
		$time->add(new DateInterval('PT' . $minutes_to_add . 'M'));
		$stamp = $time->format('H:i');
		$now = $this->input->post('jam_masuk');

		if ($now > $stamp) {
			$status = 'Terlambat';
		} else {
			$status = 'Tepat Waktu';
		}


		$this->_rules();
		$level_id = $this->input->post('level_id');
		if ($this->form_validation->run() == FALSE) {
			$this->update(encrypt_url($this->input->post('absen_id')), $this->input->post('level_id'));
		} else {
			$user = $this->input->post('user_id');
			$tanggal = $this->input->post('tanggal');
			$tanggal_lama = $this->input->post('tanggal_lama');
			if ($tanggal == $tanggal_lama) {
				$jml = 0;
			} else {
				$query = $this->db->query("SELECT * FROM absen where tanggal='$tanggal' and user_id='$user'");
				$jml = $query->num_rows();
			}
			if ($jml > 0) {
				$this->session->set_flashdata('error', 'Sudah ada data pada hari tersebut');
				if ($level_id == 2) {
					redirect(site_url('absen/guru'));
				} else if ($level_id == 3) {
					redirect(site_url('absen/pegawai'));
				} else if ($level_id == 4) {
					redirect(site_url('absen/siswa'));
				}
			} else {
				$data = array(
					'user_id' => $this->input->post('user_id', TRUE),
					'tanggal' => $this->input->post('tanggal', TRUE),
					'jam_masuk' => $this->input->post('jam_masuk', TRUE),
					'jam_pulang' => $this->input->post('jam_pulang', TRUE),
					'status_masuk' => $status,
				);

				$this->Absen_model->update($this->input->post('absen_id', TRUE), $data);
				$this->session->set_flashdata('message', 'Update Record Success');
				if ($level_id == 2) {
					redirect(site_url('absen/guru'));
				} else if ($level_id == 3) {
					redirect(site_url('absen/pegawai'));
				} else if ($level_id == 4) {
					redirect(site_url('absen/siswa'));
				}
			}
		}
	}

	public function delete($id, $level_id)
	{
		$row = $this->Absen_model->get_by_id(decrypt_url($id));

		if ($row) {
			$this->Absen_model->delete(decrypt_url($id));
			$this->session->set_flashdata('message', 'Delete Record Success');
			if (decrypt_url($level_id) == '2') {
				redirect(site_url('absen/guru'));
			} else if (decrypt_url($level_id) == '3') {
				redirect(site_url('absen/pegawai'));
			} else if (decrypt_url($level_id) == '4') {
				redirect(site_url('absen/siswa'));
			}
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			if (decrypt_url($level_id) == '2') {
				redirect(site_url('absen/guru'));
			} else if (decrypt_url($level_id) == '3') {
				redirect(site_url('absen/pegawai'));
			} else if (decrypt_url($level_id) == '4') {
				redirect(site_url('absen/siswa'));
			}
		}
	}

	public function _rules()
	{
		$this->form_validation->set_rules('user_id', 'user id', 'trim|required');
		$this->form_validation->set_rules('tanggal', 'tanggal', 'trim|required');
		$this->form_validation->set_rules('jam_masuk', 'jam masuk', 'trim|required');
		$this->form_validation->set_rules('jam_pulang', 'jam pulang', 'trim|required');
		$this->form_validation->set_rules('absen_id', 'absen_id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
	}

	public function excel()
	{
		$this->load->helper('exportexcel');
		$namaFile = "absen.xls";
		$judul = "absen";
		$tablehead = 0;
		$tablebody = 1;
		$nourut = 1;
		//penulisan header
		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");
		header("Content-Disposition: attachment;filename=" . $namaFile . "");
		header("Content-Transfer-Encoding: binary ");

		xlsBOF();

		$kolomhead = 0;
		xlsWriteLabel($tablehead, $kolomhead++, "No");
		xlsWriteLabel($tablehead, $kolomhead++, "User Id");
		xlsWriteLabel($tablehead, $kolomhead++, "Tanggal");
		xlsWriteLabel($tablehead, $kolomhead++, "Jam Masuk");
		xlsWriteLabel($tablehead, $kolomhead++, "Jam Pulang");
		xlsWriteLabel($tablehead, $kolomhead++, "Status");

		foreach ($this->Absen_model->get_all() as $data) {
			$kolombody = 0;

			//ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
			xlsWriteNumber($tablebody, $kolombody++, $nourut);
			xlsWriteNumber($tablebody, $kolombody++, $data->user_id);
			xlsWriteLabel($tablebody, $kolombody++, $data->tanggal);
			xlsWriteLabel($tablebody, $kolombody++, $data->jam_masuk);
			xlsWriteLabel($tablebody, $kolombody++, $data->jam_pulang);
			xlsWriteLabel($tablebody, $kolombody++, $data->status);

			$tablebody++;
			$nourut++;
		}

		xlsEOF();
		exit();
	}
}
