<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Guru extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		is_login();
		$this->load->model('Guru_model');
		$this->load->model('Status_guru_model');
		$this->load->model('App_setting_model');
		$this->load->library('form_validation');
		$this->load->model('User_model');
	}

	public function index()
	{
		check_admin();
		$guru = $this->Guru_model->get_all();
		$data = array(
			'guru_data' => $guru,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('template', 'guru/guru_list', $data);
	}

	public function read($id)
	{
		check_admin();
		$row = $this->Guru_model->get_by_id(decrypt_url($id));
		if ($row) {
			$data = array(
				'guru_id' => $row->guru_id,
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'nip' => $row->nip,
				'nama_guru' => $row->nama_guru,
				'jk_kelamin' => $row->jk_kelamin,
				'status_guru_id' => $row->status_guru_id,
				'alamat' => $row->alamat,
				'no_hp' => $row->no_hp,
				'tempat_lahir' => $row->tempat_lahir,
				'tanggal_lahir' => $row->tanggal_lahir,
				'photo' => $row->photo,
			);
			$this->template->load('template', 'guru/guru_read', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('guru'));
		}
	}

	public function create()
	{
		check_admin();
		$data = array(
			'button' => 'Create',
			'status_guru' => $this->Status_guru_model->get_all(),
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'action' => site_url('guru/create_action'),
			'guru_id' => set_value('guru_id'),
			'nip' => set_value('nip'),
			'nip_lama' => set_value('nip'),
			'nama_guru' => set_value('nama_guru'),
			'jk_kelamin' => set_value('jk_kelamin'),
			'status_guru_id' => set_value('status_guru_id'),
			'alamat' => set_value('alamat'),
			'no_hp' => set_value('no_hp'),
			'tempat_lahir' => set_value('tempat_lahir'),
			'tanggal_lahir' => set_value('tanggal_lahir'),
			'photo' => set_value('photo'),
			'password' => set_value('password'),
		);
		$this->template->load('template', 'guru/guru_form', $data);
	}

	public function create_action()
	{
		check_admin();
		$this->_rules(null, null, null);

		if ($this->form_validation->run() == FALSE) {
			$this->create();
		} else {
			$data2 = array(
				'password' => sha1($this->input->post('password', TRUE)),
				'username' => $this->input->post('nip', TRUE),
				'level_id' => 2
			);
			$this->db->insert('user', $data2);
			if ($this->db->affected_rows() > 0) {
				// qr code
				$this->load->library('ciqrcode'); //pemanggilan library QR CODE

				$config['cacheable']    = true; //boolean, the default is true
				$config['cachedir']     = './assets/'; //string, the default is application/cache/
				$config['errorlog']     = './assets/'; //string, the default is application/logs/
				$config['imagedir']     = './assets/assets/img/qr/guru/'; //direktori penyimpanan qr code
				$config['quality']      = true; //boolean, the default is true
				$config['size']         = '1024'; //interger, the default is 1024
				$config['black']        = array(224, 255, 255); // array, default is array(255,255,255)
				$config['white']        = array(70, 130, 180); // array, default is array(0,0,0)
				$this->ciqrcode->initialize($config);

				$image_name = $this->input->post('nip') . '_' . $this->input->post('nama_guru') . '.png'; //buat name dari qr code sesuai dengan nim

				$params['data'] = $this->input->post('nip'); //data yang akan di jadikan QR CODE
				$params['level'] = 'H'; //H=High
				$params['size'] = 10;
				$params['savename'] = FCPATH . $config['imagedir'] . $image_name; //simpan image QR CODE ke folder assets/images/
				$this->ciqrcode->generate($params); // fungsi untuk generate QR CODE

				// photo guru
				$config['upload_path']      = './assets/assets/img/guru';
				$config['allowed_types']    = 'jpg|png|jpeg';
				$config['max_size']         = 10048;
				$config['file_name']        = 'File-' . date('ymd') . '-' . substr(sha1(rand()), 0, 10);
				$this->load->library('upload', $config);
				$this->upload->initialize($config);
				$this->upload->do_upload("photo");
				$data = $this->upload->data();
				$photo = $data['file_name'];
				$data = array(
					'nip' => $this->input->post('nip', TRUE),
					'nama_guru' => $this->input->post('nama_guru', TRUE),
					'jk_kelamin' => $this->input->post('jk_kelamin', TRUE),
					'status_guru_id' => $this->input->post('status_guru_id', TRUE),
					'alamat' => $this->input->post('alamat', TRUE),
					'no_hp' => $this->input->post('no_hp', TRUE),
					'tempat_lahir' => $this->input->post('tempat_lahir', TRUE),
					'tanggal_lahir' => $this->input->post('tanggal_lahir', TRUE),
					'photo' => $photo,
					'qr_code' => $image_name,

				);
				$this->Guru_model->insert($data);
			}
			$this->session->set_flashdata('message', 'Create Record Success');
			redirect(site_url('guru'));
		}
	}

	public function update($id)
	{
		check_admin();
		$row = $this->Guru_model->get_by_id(decrypt_url($id));

		if($row->photo==''){
			$photo =set_value('photo', 'default.png');
		}else{
			$photo =set_value('photo', $row->photo);
		}

		if ($row) {
			$data = array(
				'button' => 'Update',
				'status_guru' => $this->Status_guru_model->get_all(),
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'action' => site_url('guru/update_action'),
				'guru_id' => set_value('guru_id', $row->guru_id),
				'nip' => set_value('nip', $row->nip),
				'nip_lama' => $row->nip,
				'nama_guru' => set_value('nama_guru', $row->nama_guru),
				'jk_kelamin' => set_value('jk_kelamin', $row->jk_kelamin),
				'status_guru_id' => set_value('status_guru_id', $row->status_guru_id),
				'alamat' => set_value('alamat', $row->alamat),
				'no_hp' => set_value('no_hp', $row->no_hp),
				'tempat_lahir' => set_value('tempat_lahir', $row->tempat_lahir),
				'tanggal_lahir' => set_value('tanggal_lahir', $row->tanggal_lahir),
				'photo' =>$photo,
			);
			$this->template->load('template', 'guru/guru_form', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('guru'));
		}
	}

	public function update_action()
	{
		check_admin();
		$this->_rules('update', $this->input->post('nip'), $this->input->post('nip_lama'));
		if ($this->form_validation->run() == FALSE) {
			$this->update(encrypt_url($this->input->post('guru_id')));
		} else {
			if ($this->input->post('password') == '' || $this->input->post('password') == null) {
				$data = array(
					'username' => $this->input->post('nip', TRUE),
					'level_id' => 2
				);
				$this->db->where('username', $this->input->post('nip_lama'));
				$this->db->update('user', $data);
			} else {
				$data = array(
					'password' => sha1($this->input->post('password', TRUE)),
					'username' => $this->input->post('nip', TRUE),
					'level_id' => 2
				);
				$this->db->where('username', $this->input->post('nip_lama'));
				$this->db->update('user', $data);
			}
			// hapus qr code
			$id = $this->input->post('guru_id');
			$row = $this->Guru_model->get_by_id($id);
			if ($row->qr_code == null || $row->qr_code == '') {
			} else {
				$target_file = './assets/assets/img/qr/guru/' . $row->qr_code;
				unlink($target_file);
			}
			// buat qr code baru
			$this->load->library('ciqrcode'); //pemanggilan library QR CODE
			$config['cacheable']    = true; //boolean, the default is true
			$config['cachedir']     = './assets/'; //string, the default is application/cache/
			$config['errorlog']     = './assets/'; //string, the default is application/logs/
			$config['imagedir']     = './assets/assets/img/qr/guru/'; //direktori penyimpanan qr code
			$config['quality']      = true; //boolean, the default is true
			$config['size']         = '1024'; //interger, the default is 1024
			$config['black']        = array(224, 255, 255); // array, default is array(255,255,255)
			$config['white']        = array(70, 130, 180); // array, default is array(0,0,0)
			$this->ciqrcode->initialize($config);
			$image_name = $this->input->post('nip') . '_' . $this->input->post('nama_guru') . '.png'; //buat name dari qr code sesuai dengan nim
			$params['data'] = $this->input->post('nip'); //data yang akan di jadikan QR CODE
			$params['level'] = 'H'; //H=High
			$params['size'] = 10;
			$params['savename'] = FCPATH . $config['imagedir'] . $image_name;
			$this->ciqrcode->generate($params);
			// untuk uplaod photo
			$config['upload_path']      = './assets/assets/img/guru';
			$config['allowed_types']    = 'jpg|png|jpeg';
			$config['max_size']         = 10048;
			$config['file_name']        = 'File-' . date('ymd') . '-' . substr(sha1(rand()), 0, 10);
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			if ($this->upload->do_upload("photo")) {
				$id = $this->input->post('guru_id');
				$row = $this->Guru_model->get_by_id($id);
				$data = $this->upload->data();
				$photo = $data['file_name'];
				if ($row->photo == null || $row->photo == '') {
				} else {
					$target_file = './assets/assets/img/guru/' . $row->photo;
					unlink($target_file);
				}
			} else {
				$photo = $this->input->post('photo_lama');
			}
			$data = array(
				'nip' => $this->input->post('nip', TRUE),
				'nama_guru' => $this->input->post('nama_guru', TRUE),
				'jk_kelamin' => $this->input->post('jk_kelamin', TRUE),
				'status_guru_id' => $this->input->post('status_guru_id', TRUE),
				'alamat' => $this->input->post('alamat', TRUE),
				'no_hp' => $this->input->post('no_hp', TRUE),
				'tempat_lahir' => $this->input->post('tempat_lahir', TRUE),
				'tanggal_lahir' => $this->input->post('tanggal_lahir', TRUE),
				'photo' => $photo,
				'qr_code' => $image_name,
			);
			$this->Guru_model->update($this->input->post('guru_id', TRUE), $data);
			$this->session->set_flashdata('message', 'Update Record Success');
			redirect(site_url('guru'));
		}
	}

	public function delete($id)
	{
		check_admin();
		$row = $this->Guru_model->get_by_id(decrypt_url($id));
		if ($row) {
			if ($row->photo == null || $row->photo == '') {
			} else {
				$target_file = './assets/assets/img/guru/' . $row->photo;
				unlink($target_file);
			}

			if ($row->qr_code == null || $row->qr_code == '') {
			} else {
				$target_file = './assets/assets/img/qr/guru/' . $row->qr_code;
				unlink($target_file);
			}


			$this->Guru_model->delete(decrypt_url($id));
			if ($this->db->affected_rows() > 0) {
				$this->db->where('username', $row->nip);
				$this->db->delete('user');
			}
			$this->session->set_flashdata('message', 'Delete Record Success');
			redirect(site_url('guru'));
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('guru'));
		}
	}

	public function _rules($type, $new, $original_value)
	{
		if ($type != null) {
			if ($new == $original_value) {
				$is_unique =  '';
			} else {
				$is_unique =  '|is_unique[guru.nip]|is_unique[user.username]';
			}
		} else {
			$is_unique =  '|is_unique[guru.nip]|is_unique[user.username]';
			$this->form_validation->set_rules('password', 'Password', 'trim|required');
		}
		$this->form_validation->set_rules('nip', 'nip', 'trim|required' . $is_unique);
		$this->form_validation->set_rules('nama_guru', 'nama guru', 'trim|required');
		$this->form_validation->set_rules('jk_kelamin', 'jk kelamin', 'trim|required');
		$this->form_validation->set_rules('status_guru_id', 'status guru id', 'trim|required');
		$this->form_validation->set_rules('alamat', 'alamat', 'trim|required');
		$this->form_validation->set_rules('no_hp', 'no hp', 'trim|required');
		$this->form_validation->set_rules('tempat_lahir', 'tempat lahir', 'trim|required');
		$this->form_validation->set_rules('tanggal_lahir', 'tanggal lahir', 'trim|required');
		$this->form_validation->set_rules('photo', 'photo', 'trim');
		$this->form_validation->set_rules('guru_id', 'guru_id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
	}

	public function excel()
	{
		check_admin();

		$spreadsheet = new Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();

		$sheet->setCellValue('A1', 'No');
		$sheet->setCellValue('B1', 'nip');
		$sheet->setCellValue('C1', 'nama_guru');
		$sheet->setCellValue('D1', 'jk_kelamin');
		$sheet->setCellValue('E1', 'status_guru_id');
		$sheet->setCellValue('F1', 'alamat');
		$sheet->setCellValue('G1', 'no_hp');
		$sheet->setCellValue('H1', 'tempat_lahir');
		$sheet->setCellValue('I1', 'tanggal_lahir');
		// Panggil function view yang ada di SiswaModel untuk menampilkan semua data siswanya
		$guru = $this->Guru_model->get_all();
		$no = 1; // Untuk penomoran tabel, di awal set dengan 1
		$numrow = 2; // Set baris pertama untuk isi tabel adalah baris ke 4
		foreach ($guru as $data) { // Lakukan looping pada variabel Guru
			$sheet->setCellValue('A' . $numrow, $no);
			$sheet->setCellValue('B' . $numrow, $data->nip);
			$sheet->setCellValue('C' . $numrow, $data->nama_guru);
			$sheet->setCellValue('D' . $numrow, $data->jk_kelamin);
			$sheet->setCellValue('E' . $numrow, $data->status_guru_id);
			$sheet->setCellValue('F' . $numrow, $data->alamat);
			$sheet->setCellValue('G' . $numrow, $data->no_hp);
			$sheet->setCellValue('H' . $numrow, $data->tempat_lahir);
			$sheet->setCellValue('I' . $numrow, $data->tanggal_lahir);
			$no++; // Tambah 1 setiap kali looping
			$numrow++; // Tambah 1 setiap kali looping
		}

		// Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
		$sheet->getDefaultRowDimension()->setRowHeight(-1);
		// Set judul file excel nya
		$sheet->setTitle("Data Guru");
		// Proses file excel
		header('Content-Type: application/vnd.ms-excel'); // generate excel file
		header('Content-Disposition: attachment; filename="Data Guru '.date('Y-m-d').'.xlsx"'); // Set nama file excel nya
		header('Cache-Control: max-age=0');
		ob_end_clean();
		$writer = new Xlsx($spreadsheet);
		$writer->save('php://output');
		die;
		
	}

	public function download($gambar)
	{
		check_admin();
		force_download('assets/assets/img/guru/' . $gambar, NULL);
	}

	public function cetak_semua()
	{
		check_admin();
		$guru = $this->Guru_model->get_all();
		$data = array(
			'siswa' => $guru,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);

		$this->load->view('guru/cetak_semua', $data);
	}

	public function cetak($id)
	{
		$row = $this->Guru_model->get_by_id(decrypt_url($id));
		$data = array(
			'guru_id' => $row->guru_id,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'nip' => $row->nip,
			'qr_code' => $row->qr_code,
			'nama_guru' => $row->nama_guru,
			'jk_kelamin' => $row->jk_kelamin,
			'status_guru_id' => $row->status_guru_id,
			'alamat' => $row->alamat,
			'no_hp' => $row->no_hp,
			'tempat_lahir' => $row->tempat_lahir,
			'tanggal_lahir' => $row->tanggal_lahir,
			'photo' => $row->photo,
		);
		$this->load->view('guru/cetak', $data);
	}

	public function preview_excel()
	{
		$str = '';
		$fileName = $_FILES['file_excel']['name'];

		$config['upload_path'] = './temp_doc/'; //path upload
		$config['file_name'] = $fileName;  // nama file
		$config['allowed_types'] = 'xls|xlsx'; //tipe file yang diperbolehkan
		$config['max_size'] = 10000; // maksimal sizze

		$this->load->library('upload'); //meload librari upload
		$this->upload->initialize($config);

		if (!$this->upload->do_upload('file_excel')) {
			echo $this->upload->display_errors();
			exit();
		}

		$inputFileName = './temp_doc/'.$this->upload->data('file_name');

		try {

			$inputFileType = IOFactory::identify($inputFileName);
			$objReader = IOFactory::createReader($inputFileType);
			$objExcel = $objReader->load($inputFileName);
		} catch (Exception $e) {
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e->getMessage());
		}

		$sheet = $objExcel->getActiveSheet()->toArray(null, true, true, true);
		$sh = $objExcel->getActiveSheet();

		$numrow = 1;

		for ($i = 3; $i <= count($sheet); $i++) {
			$kategoridata = $sh->getCellByColumnAndRow(1, 1)->getValue();

			$identity_number = $sheet[$i]['A'];
			$nama_guru = $sheet[$i]['B'];
			$jenis_kelamin = $sheet[$i]['C'];
			$status_guru = $sheet[$i]['D'];
			$alamat = $sheet[$i]['E'];
			$no_hp = $sheet[$i]['F'];
			$tempat_lahir = $sheet[$i]['G'];
			$tanggal_lahir = $sheet[$i]['H'];
			$password = $sheet[$i]['I'];

			$realcount = $i - 1;

			$cekdatadidb = $this->User_model->get_by_username($identity_number);
			if ($cekdatadidb) {
				$str .= '<tr class="bg-danger not-allowed-to-insert-excel">
							<td>' . $identity_number . '</td>
							<td>' . $nama_guru . '</td>
							<td>' . $jenis_kelamin . '</td>
							<td>' . $status_guru . '</td>
							<td>' . $alamat . '</td>
							<td>' . $no_hp . '</td>
							<td>' . $tempat_lahir . '</td>
							<td>' . $tanggal_lahir . '</td>
							<td></td>
						</tr>';
			} else {
				$str .= '<tr>
							<td>' . $identity_number . '<input type="hidden" value="' . $identity_number . '" class="nip" name="nip[]"/></td>
							<td>' . $nama_guru . '<input type="hidden" value="' . $nama_guru . '" class="nama_guru" name="nama_guru[]"/></td>
							<td>' . $jenis_kelamin . '<input type="hidden" value="' . $jenis_kelamin . '" class="jenis_kelamin" name="jenis_kelamin[]"/></td>
							<td>' . $status_guru . '<input type="hidden" value="' . $status_guru . '" class="status_guru" name="status_guru[]"/></td>
							<td>' . $alamat . '<input type="hidden" value="' . $alamat . '" class="alamat" name="alamat[]"/></td>
							<td>' . $no_hp . '<input type="hidden" value="' . $no_hp . '" class="no_hp" name="no_hp[]"/></td>
							<td>' . $tempat_lahir . '<input type="hidden" value="' . $tempat_lahir . '" class="tempat_lahir" name="tempat_lahir[]"/></td>
							<td>' . $tanggal_lahir . '<input type="hidden" value="' . $tanggal_lahir . '" class="tanggal_lahir" name="tanggal_lahir[]"/></td>
							<td>' . $password . '<input type="hidden" value="' . $password . '" class="password" name="password[]"/></td>
						</tr>';
			}

			$numrow++;
		}
		//print_r($arraysoaldata);

		unlink($inputFileName);
		$arrayresp = array(
			'status' => 'ok',
			'message' => 'success',
			'data' => $str
		);
		echo json_encode($arrayresp);
	}

	public function insert_all_from_excel()
	{
		$nip = $this->input->post('nip');
		$nama_guru = $this->input->post('nama_guru');
		$jenis_kelamin = $this->input->post('jenis_kelamin');
		$status_guru = $this->input->post('status_guru');
		$alamat = $this->input->post('alamat');
		$no_hp = $this->input->post('no_hp');
		$tempat_lahir = $this->input->post('tempat_lahir');
		$tanggal_lahir = $this->input->post('tanggal_lahir');
		$password = $this->input->post('password');

		foreach ($nip as $key => $value) {
			$data2 = array(
				'password' => sha1($password[$key]),
				'username' => $value,
				'level_id' => 2
			);

			$this->db->insert('user', $data2);
			// qr code
			$this->load->library('ciqrcode'); //pemanggilan library QR CODE

			$config['cacheable']    = true; //boolean, the default is true
			$config['cachedir']     = './assets/'; //string, the default is application/cache/
			$config['errorlog']     = './assets/'; //string, the default is application/logs/
			$config['imagedir']     = './assets/assets/img/qr/guru/'; //direktori penyimpanan qr code
			$config['quality']      = true; //boolean, the default is true
			$config['size']         = '1024'; //interger, the default is 1024
			$config['black']        = array(224, 255, 255); // array, default is array(255,255,255)
			$config['white']        = array(70, 130, 180); // array, default is array(0,0,0)
			$this->ciqrcode->initialize($config);

			$image_name = $value . '_' . $nama_guru[$key] . '.png'; //buat name dari qr code sesuai dengan nim

			$params['data'] = $value; //data yang akan di jadikan QR CODE
			$params['level'] = 'H'; //H=High
			$params['size'] = 10;
			$params['savename'] = FCPATH . $config['imagedir'] . $image_name; //simpan image QR CODE ke folder assets/images/
			$this->ciqrcode->generate($params); // fungsi untuk generate QR CODE
			$data = array(
				'nip' => $value,
				'nama_guru' => $nama_guru[$key],
				'jk_kelamin' => $jenis_kelamin[$key],
				'status_guru_id' => $status_guru[$key],
				'alamat' => $alamat[$key],
				'no_hp' => $no_hp[$key],
				'tempat_lahir' => $tempat_lahir[$key],
				'tanggal_lahir' => date('Y-m-d', strtotime($tanggal_lahir[$key])),
				'photo' => '',
				'qr_code' => $image_name,

			);
			$this->Guru_model->insert($data);
		}
		$this->session->set_flashdata('message', 'Create Record Success');
		redirect(site_url('guru'));
	}
}
