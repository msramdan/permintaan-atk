<?php
defined('BASEPATH') or exit('No direct script access allowed');
// set timezone
date_default_timezone_set('Asia/Jakarta');

class Cetak extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->model('App_setting_model');
	}

	public function index()
	{
		echo 'ngapain u';
	}

	public function laporan()
	{
		$data = array(
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'user_id' => $this->input->get('user_id', TRUE),
			'bulan' => $this->input->get('bulan', TRUE),
			'tahun' => $this->input->get('tahun', TRUE),
			'area' => $this->input->get('area', TRUE),
		);
		$mpdf = new \Mpdf\Mpdf([
			'mode' => 'utf-8',
			'format' => 'A3-L',
			'mode' => 'c'
		]);
		if ($data['area'] == 'guru') {
			$html = $this->load->view('laporan/cetak_view_laporan_guru', $data, TRUE);
			$mpdf->WriteHTML($html);
			$mpdf->Output();
		} else if ($data['area'] == 'pegawai') {
			$html = $this->load->view('laporan/cetak_view_laporan_pegawai', $data, TRUE);
			$mpdf->WriteHTML($html);
			$mpdf->Output();
		} else if ($data['area'] == 'siswa') {
			$html = $this->load->view('laporan/cetak_view_laporan_siswa', $data, TRUE);
			$mpdf->WriteHTML($html);
			$mpdf->Output();
		} else {
			echo 'p';
		}
	}

	public function laporan_view_debug()
	{
		$data = array(
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'user_id' => $this->input->get('user_id', TRUE),
			'bulan' => $this->input->get('bulan', TRUE),
			'tahun' => $this->input->get('tahun', TRUE),
			'area' => $this->input->get('area', TRUE),
		);

		if ($data['area'] == 'guru') {
			$this->load->view('laporan/cetak_view_laporan_guru', $data);
		} else if ($data['area'] == 'pegawai') {
			$this->load->view('laporan/cetak_view_laporan_pegawai', $data);
		} else if ($data['area'] == 'siswa') {
			$this->load->view('laporan/cetak_view_laporan_siswa', $data);
		} else {
			echo 'p';
		}
	}

	public function surat_panggilan($id_surat_panggilan)
	{
		$tgl = $this->input->post('tgl');
		$waktu = $this->input->post('waktu');
		$tempat = $this->input->post('tempat');
		$ambil_nama_hari_eng   = date('D', strtotime($tgl));
		$hari = hari_ini($ambil_nama_hari_eng);

		$tahunajaran = cek_tahun_pelajaran_berjalan();
		$getdatasuratpanggilan = $this->db->select('*')->from('surat_panggilan')
			->join('siswa', 'surat_panggilan.siswa_id = siswa.siswa_id')->join('kelas', 'siswa.kelas_id = kelas.kelas_id')->where('id_surat_panggilan', $id_surat_panggilan)->get()->row();
		$data = array(
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'user_id' => $this->input->get('user_id', TRUE),
			'keterangan' => $getdatasuratpanggilan->keterangan,
			'id_surat_panggilan' => $getdatasuratpanggilan->id_surat_panggilan,
			'asal_kelas' => $getdatasuratpanggilan->nama_kelas,
			'tahun_ajaran' => date('Y', strtotime($tahunajaran->tgl_awal)) . '/' . date('Y', strtotime($tahunajaran->tgl_akhir)),
			'nama_siswa' => $getdatasuratpanggilan->nama_siswa,
			'nisn' => $getdatasuratpanggilan->nisn,
			'kelas' => $getdatasuratpanggilan->nama_kelas,
			'walikelas' => $getdatasuratpanggilan->walikelas,
			'tgl' => $tgl,
			'hari' => $hari,
			'waktu' => $waktu,
			'tempat' => $tempat,
		);
		$mpdf = new \Mpdf\Mpdf([
			'mode' => 'utf-8',
			'format' => 'A4-P',
			'mode' => 'c'
		]);
		$html = $this->load->view('surat_panggilan/v_cetak_surat_panggilan', $data, TRUE);
		$mpdf->WriteHTML($html);
		$mpdf->Output();
	}
}
