<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Hari_libur extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
		check_admin();
        $this->load->model('Hari_libur_model');
		$this->load->model('App_setting_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $hari_libur = $this->Hari_libur_model->get_all();
        $data = array(
            'hari_libur_data' => $hari_libur,
			'sett_apps' =>$this->App_setting_model->get_by_id(1),
        );
        $this->template->load('template','hari_libur/hari_libur_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Hari_libur_model->get_by_id(decrypt_url($id));
        if ($row) {
            $data = array(
		'hari_libur_id' => $row->hari_libur_id,
		'tanggal' => $row->tanggal,
		'keterangan' => $row->keterangan,
		'sett_apps' =>$this->App_setting_model->get_by_id(1),
	    );
            $this->template->load('template','hari_libur/hari_libur_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('hari_libur'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('hari_libur/create_action'),
	    'hari_libur_id' => set_value('hari_libur_id'),
		'sett_apps' =>$this->App_setting_model->get_by_id(1),
	    'tanggal' => set_value('tanggal'),
	    'keterangan' => set_value('keterangan'),
	);
        $this->template->load('template','hari_libur/hari_libur_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'tanggal' => $this->input->post('tanggal',TRUE),
		'keterangan' => $this->input->post('keterangan',TRUE),
	    );

            $this->Hari_libur_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('hari_libur'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Hari_libur_model->get_by_id(decrypt_url($id));

        if ($row) {
            $data = array(
                'button' => 'Update',
				'sett_apps' =>$this->App_setting_model->get_by_id(1),
                'action' => site_url('hari_libur/update_action'),
		'hari_libur_id' => set_value('hari_libur_id', $row->hari_libur_id),
		'tanggal' => set_value('tanggal', $row->tanggal),
		'keterangan' => set_value('keterangan', $row->keterangan),
	    );
            $this->template->load('template','hari_libur/hari_libur_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('hari_libur'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
			$this->update(encrypt_url($this->input->post('hari_libur_id')));
        } else {
            $data = array(
		'tanggal' => $this->input->post('tanggal',TRUE),
		'keterangan' => $this->input->post('keterangan',TRUE),
	    );

            $this->Hari_libur_model->update($this->input->post('hari_libur_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('hari_libur'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Hari_libur_model->get_by_id(decrypt_url($id));

        if ($row) {
            $this->Hari_libur_model->delete(decrypt_url($id));
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('hari_libur'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('hari_libur'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('tanggal', 'tanggal', 'trim|required');
	$this->form_validation->set_rules('keterangan', 'keterangan', 'trim|required');

	$this->form_validation->set_rules('hari_libur_id', 'hari_libur_id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "hari_libur.xls";
        $judul = "hari_libur";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Tanggal");
	xlsWriteLabel($tablehead, $kolomhead++, "Keterangan");

	foreach ($this->Hari_libur_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tanggal);
	    xlsWriteLabel($tablebody, $kolombody++, $data->keterangan);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

}

/* End of file Hari_libur.php */
/* Location: ./application/controllers/Hari_libur.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2022-01-11 09:56:37 */
/* http://harviacode.com */
