<?php
defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Jayapura');

class Dashboard_user extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		is_login();
		$this->load->model('App_setting_model');
		$this->load->model('Guru_model');
		$this->load->model('Absen_model');
		$this->load->model('Pengumuman_model');
		$this->load->model('Pegawai_model');
		$this->load->model('Siswa_model');
		$this->load->model('User_model');
		$this->load->model('Izin_sakit_model');
	}

	public function index()
	{
		$row = $this->Pengumuman_model->get_by_id(1);
		if ($row) {
			$data = array(
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'text' => $row->text,
				'status_pengumuman' => $row->status,
			);
		}
		$this->template->load('web_user/template_user', 'dashboard_user', $data);
	}

	public function kartu($id)
	{
		if ($this->fungsi->user_login()->level_id == '2') {
			$row = $this->Guru_model->get_by_id(decrypt_url($id));
			$data = array(
				'guru_id' => $row->guru_id,
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'nip' => $row->nip,
				'qr_code' => $row->qr_code,
				'nama_guru' => $row->nama_guru,
				'jk_kelamin' => $row->jk_kelamin,
				'status_guru_id' => $row->status_guru_id,
				'alamat' => $row->alamat,
				'no_hp' => $row->no_hp,
				'tempat_lahir' => $row->tempat_lahir,
				'tanggal_lahir' => $row->tanggal_lahir,
				'photo' => $row->photo,
			);
			$this->load->view('guru/cetak', $data);
		} else if ($this->fungsi->user_login()->level_id == '3') {
			$row = $this->Pegawai_model->get_by_id(decrypt_url($id));
			$data = array(
				'pegawai_id' => $row->pegawai_id,
				'nip' => $row->nip,
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'nama_pegawai' => $row->nama_pegawai,
				'jk_kelamin' => $row->jk_kelamin,
				'status_pegawai_id' => $row->status_pegawai_id,
				'alamat' => $row->alamat,
				'no_hp' => $row->no_hp,
				'tempat_lahir' => $row->tempat_lahir,
				'tanggal_lahir' => $row->tanggal_lahir,
				'photo' => $row->photo,
				'qr_code' => $row->qr_code,
			);
			$this->load->view('pegawai/cetak', $data);
		} else if ($this->fungsi->user_login()->level_id == '4') {
			$row = $this->Siswa_model->get_by_id(decrypt_url($id));
			$data = array(
				'siswa_id' => $row->siswa_id,
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'nisn' => $row->nisn,
				'nama_siswa' => $row->nama_siswa,
				'jk_kelamin' => $row->jk_kelamin,
				'kelas_id' => $row->kelas_id,
				'alamat' => $row->alamat,
				'tempat_lahir' => $row->tempat_lahir,
				'tanggal_lahir' => $row->tanggal_lahir,
				'photo' => $row->photo,
				'nama_wali_siswa' => $row->nama_wali_siswa,
				'no_hp_wali_siswa' => $row->no_hp_wali_siswa,
				'qr_code' => $row->qr_code,

			);
			$this->load->view('siswa/cetak', $data);
		}
	}

	public function absen()
	{
		$absen = $this->Absen_model->self($this->session->userdata('userid'));
		$data = array(
			'absen_data' => $absen,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('web_user/template_user', 'web_user/absen/absen_list', $data);
	}


	public function izin_sakit()
	{
		$izin_sakit = $this->Izin_sakit_model->get_all_by_id($this->session->userdata('userid'));
		$data = array(
			'izin_sakit_data' => $izin_sakit,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('web_user/template_user', 'web_user/izin_sakit/izin_sakit_list', $data);
	}

	public function create_izin_sakit()
	{
		$data = array(
			'button' => 'Create',
			'action' => site_url('Dashboard_user/create_action_izin_sakit'),
			'izin_sakit_id' => set_value('izin_sakit_id'),
			'sett_apps' => $this->App_setting_model->get_by_id(1),
			'user_id' => $this->session->userdata('userid'),
			'photo' => set_value('photo'),
			'tanggal' => set_value('tanggal'),
			'keterangan' => set_value('keterangan'),
			'status' => set_value('status'),
			'deskripsi' => set_value('deskripsi'),
		);
		$this->template->load('web_user/template_user', 'web_user/izin_sakit/izin_sakit_form', $data);
	}

	public function create_action_izin_sakit()
	{
		$this->_rules();
		if ($this->form_validation->run() == FALSE) {
			$this->create_izin_sakit();
		} else {
			$user = $this->input->post('user_id');
			$tanggal = $this->input->post('tanggal');
			$tanggal_hari_ini = $this->input->post('tanggal');
			$day = date('l', strtotime($tanggal));
			$cek_hari_libur = hari_libur($this->input->post('tanggal'));
			$query = $this->db->query("SELECT * FROM izin_sakit where tanggal='$tanggal' and user_id='$user'");
			$jml = $query->num_rows();
			if ($jml > 0) {
				$this->session->set_flashdata('error', 'Sudah ada data pada hari tersebut');
				redirect(site_url('Dashboard_user/izin_sakit'));
			} else if ($day == 'Sunday') {
				$this->session->set_flashdata('error', 'Tidak bisa pengajuan izin/sakit hari minggu');
				redirect(site_url('Dashboard_user/izin_sakit'));
			} else if ($cek_hari_libur == true) {
				$this->session->set_flashdata('error', 'Tidak bisa pengajuan izin/sakit hari libur');
				redirect(site_url('Dashboard_user/izin_sakit'));
			} else {
				$config['upload_path']      = './assets/assets/img/izin';
				$config['allowed_types']    = 'jpg|png|jpeg|pdf|doc|docx';
				$config['max_size']         = 10048;
				$config['file_name']        = 'File-' . date('ymd') . '-' . substr(sha1(rand()), 0, 10);
				$this->load->library('upload', $config);
				$this->upload->initialize($config);
				$this->upload->do_upload("photo");
				$data = $this->upload->data();
				$photo = $data['file_name'];

				$data = array(
					'user_id' => $this->input->post('user_id', TRUE),
					'photo' => $photo,
					'keterangan' => $this->input->post('keterangan', TRUE),
					'tanggal' => $this->input->post('tanggal', TRUE),
					'status' => 'Waiting',
					'deskripsi' => $this->input->post('deskripsi', TRUE),
				);

				$this->Izin_sakit_model->insert($data);
				$this->session->set_flashdata('message', 'Create Record Success');
				redirect(site_url('Dashboard_user/izin_sakit'));
			}
		}
	}

	public function update_izin_sakit($id)
	{
		$row = $this->Izin_sakit_model->get_by_id(decrypt_url($id));
		if ($row) {
			$data = array(
				'button' => 'Update',
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'action' => site_url('Dashboard_user/update_action_izin_sakit'),
				'izin_sakit_id' => set_value('izin_sakit_id', $row->izin_sakit_id),
				'user_id' => set_value('user_id', $row->user_id),
				'photo' => set_value('photo', $row->photo),
				'tanggal' => set_value('tanggal', $row->tanggal),
				'keterangan' => set_value('keterangan', $row->keterangan),
				'status' => set_value('status', $row->status),
				'deskripsi' => set_value('deskripsi', $row->deskripsi),
			);
			$this->template->load('web_user/template_user', 'web_user/izin_sakit/izin_sakit_form', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('Dashboard_user/izin_sakit'));
		}
	}

	public function update_action_izin_sakit()
	{
		$this->_rules();
		if ($this->form_validation->run() == FALSE) {
			$this->update_izin_sakit(encrypt_url($this->input->post('izin_sakit_id')));
		} else {
			$config['upload_path']      = './assets/assets/img/izin';
			$config['allowed_types']    = 'jpg|png|jpeg|pdf|doc|docx';
			$config['max_size']         = 10048;
			$config['file_name']        = 'File-' . date('ymd') . '-' . substr(sha1(rand()), 0, 10);
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			if ($this->upload->do_upload("photo")) {
				$id = $this->input->post('izin_sakit_id');
				$row = $this->Izin_sakit_model->get_by_id($id);
				$data = $this->upload->data();
				$photo = $data['file_name'];
				if ($row->photo == null || $row->photo == '') {
				} else {
					$target_file = './assets/assets/img/izin/' . $row->photo;
					unlink($target_file);
				}
			} else {
				$photo = $this->input->post('photo_lama');
			}

			$data = array(
				'user_id' => $this->input->post('user_id', TRUE),
				'photo' => $photo,
				'keterangan' => $this->input->post('keterangan', TRUE),
				'deskripsi' => $this->input->post('deskripsi', TRUE),
			);

			$this->Izin_sakit_model->update($this->input->post('izin_sakit_id', TRUE), $data);
			$this->session->set_flashdata('message', 'Update Record Success');
			redirect(site_url('Dashboard_user/izin_sakit'));
		}
	}

	public function delete_izin_sakit($id)
	{
		$row = $this->Izin_sakit_model->get_by_id(decrypt_url($id));
		if ($row) {
			if ($row->photo == null || $row->photo == '') {
			} else {
				$target_file = './assets/assets/img/izin/' . $row->photo;
				unlink($target_file);
			}

			$this->Izin_sakit_model->delete(decrypt_url($id));
			$this->session->set_flashdata('message', 'Delete Record Success');
			redirect(site_url('Dashboard_user/izin_sakit'));
		} else {
			$this->session->set_flashdata('error', 'Record Not Found');
			redirect(site_url('Dashboard_user/izin_sakit'));
		}
	}

	public function _rules()
	{
		$this->form_validation->set_rules('user_id', 'user id', 'trim|required');
		$this->form_validation->set_rules('photo', 'photo', 'trim');
		$this->form_validation->set_rules('keterangan', 'keterangan', 'trim|required');
		$this->form_validation->set_rules('tanggal', 'Tanggal', 'trim|required');
		$this->form_validation->set_rules('deskripsi', 'deskripsi', 'trim|required');

		$this->form_validation->set_rules('izin_sakit_id', 'izin_sakit_id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
	}

	public function download_izin_sakit($gambar)
	{
		force_download('assets/assets/img/izin/' . $gambar, NULL);
	}

	public function edit_profile()
	{
		$row = $this->User_model->get_by_id($this->session->userdata('userid'));
		if ($row) {
			$data = array(
				'user_id' => $row->user_id,
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'username' => $row->username,
				'password' => $row->password,
				'level_id' => $row->level_id,
			);
			$this->template->load('web_user/template_user', 'web_user/edit_profile', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('dashboard_user'));
		}
	}

	public function update_profile()
	{

		if ($this->fungsi->user_login()->level_id == '2') {
			$config['upload_path']      = './assets/assets/img/guru';
		} else if ($this->fungsi->user_login()->level_id == '3') {
			$config['upload_path']      = './assets/assets/img/pegawai';
		} else if ($this->fungsi->user_login()->level_id == '4') {
			$config['upload_path']      = './assets/assets/img/siswa';
		}

		$config['allowed_types']    = 'jpg|png|jpeg';
		$config['max_size']         = 10048;
		$config['file_name']        = 'File-' . date('ymd') . '-' . substr(sha1(rand()), 0, 10);
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		if ($this->upload->do_upload("photo")) {

			if ($this->fungsi->user_login()->level_id == '2') {
				$row = $this->Guru_model->get_by_id(guru_id($this->input->post('user_id')));
			} else if ($this->fungsi->user_login()->level_id == '3') {
				$row = $this->Pegawai_model->get_by_id(pegawai_id($this->input->post('user_id')));
			} else if ($this->fungsi->user_login()->level_id == '4') {
				$row = $this->Siswa_model->get_by_id(siswa_id($this->input->post('user_id')));
			}

			$data = $this->upload->data();
			$photo = $data['file_name'];
			if ($row->photo == null || $row->photo == '') {
			} else {
				if ($this->fungsi->user_login()->level_id == '2') {
					$target_file = './assets/assets/img/guru/' . $row->photo;
				} else if ($this->fungsi->user_login()->level_id == '3') {
					$target_file = './assets/assets/img/pegawai/' . $row->photo;
				} else if ($this->fungsi->user_login()->level_id == '4') {
					$target_file = './assets/assets/img/siswa/' . $row->photo;
				}
				unlink($target_file);
			}
		} else {
			$photo = $this->input->post('photo_lama');
		}
		$data = array(
			'photo' => $photo,
		);

		if ($this->fungsi->user_login()->level_id == '2') {
			$this->Guru_model->update(guru_id($this->input->post('user_id')), $data);
		} else if ($this->fungsi->user_login()->level_id == '3') {
			$this->Pegawai_model->update(pegawai_id($this->input->post('user_id')), $data);
		} else if ($this->fungsi->user_login()->level_id == '4') {
			$this->Siswa_model->update(siswa_id($this->input->post('user_id')), $data);
		}

		if ($this->input->post('password') != '' || $this->input->post('password') != null) {
			$data = array(
				'password' => sha1($this->input->post('password', TRUE))
			);
			$this->db->where('user_id', $this->input->post('user_id'));
			$this->db->update('user', $data);
		}
		$this->session->set_flashdata('message', 'Update berhasil');
		redirect(site_url('dashboard_user'));
	}
}
