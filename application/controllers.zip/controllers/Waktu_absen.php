<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Waktu_absen extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		is_login();
		check_admin();
		$this->load->model('Waktu_absen_model');
		$this->load->model('App_setting_model');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$waktu_absen = $this->Waktu_absen_model->get_all();
		$data = array(
			'waktu_absen_data' => $waktu_absen,
			'sett_apps' => $this->App_setting_model->get_by_id(1),
		);
		$this->template->load('template', 'waktu_absen/waktu_absen_list', $data);
	}



	public function update($id)
	{
		$row = $this->Waktu_absen_model->get_by_id(decrypt_url($id));

		if ($row) {
			$data = array(
				'button' => 'Update',
				'sett_apps' => $this->App_setting_model->get_by_id(1),
				'action' => site_url('waktu_absen/update_action'),
				'waktu_absen' => set_value('waktu_absen', $row->waktu_absen),
				'nama_hari' => set_value('nama_hari', $row->nama_hari),
				'jam_masuk_guru' => set_value('jam_masuk_guru', $row->jam_masuk_guru),
				'absen_terlambat_guru' => set_value('absen_terlambat_guru', $row->absen_terlambat_guru),
				'jam_masuk_siswa' => set_value('jam_masuk_siswa', $row->jam_masuk_siswa),
				'absen_terlambat_siswa' => set_value('absen_terlambat_siswa', $row->absen_terlambat_siswa),
				'jam_pulang_guru' => set_value('jam_pulang_guru', $row->jam_pulang_guru),
				'jam_pulang_siswa' => set_value('jam_pulang_siswa', $row->jam_pulang_siswa),
			);
			$this->template->load('template', 'waktu_absen/waktu_absen_form', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('waktu_absen'));
		}
	}

	public function update_action()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->update($this->input->post('waktu_absen', TRUE));
		} else {
			$data = array(
				'nama_hari' => $this->input->post('nama_hari', TRUE),
				'jam_masuk_guru' => $this->input->post('jam_masuk_guru', TRUE),
				'absen_terlambat_guru' => $this->input->post('absen_terlambat_guru', TRUE),
				'jam_masuk_siswa' => $this->input->post('jam_masuk_siswa', TRUE),
				'absen_terlambat_siswa' => $this->input->post('absen_terlambat_siswa', TRUE),
				'jam_pulang_guru' => $this->input->post('jam_pulang_guru', TRUE),
				'jam_pulang_siswa' => $this->input->post('jam_pulang_siswa', TRUE),
			);

			$this->Waktu_absen_model->update($this->input->post('waktu_absen', TRUE), $data);
			$this->session->set_flashdata('message', 'Update Record Success');
			redirect(site_url('waktu_absen'));
		}
	}


	public function _rules()
	{
		$this->form_validation->set_rules('nama_hari', 'nama hari', 'trim|required');
		$this->form_validation->set_rules('jam_masuk_guru', 'jam masuk guru', 'trim|required');
		$this->form_validation->set_rules('absen_terlambat_guru', 'absen terlambat guru', 'trim|required');
		$this->form_validation->set_rules('jam_masuk_siswa', 'jam masuk siswa', 'trim|required');
		$this->form_validation->set_rules('absen_terlambat_siswa', 'absen terlambat siswa', 'trim|required');
		$this->form_validation->set_rules('jam_pulang_guru', 'jam pulang guru', 'trim|required');
		$this->form_validation->set_rules('jam_pulang_siswa', 'jam pulang siswa', 'trim|required');

		$this->form_validation->set_rules('waktu_absen', 'waktu_absen', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
	}

	public function excel()
	{
		$this->load->helper('exportexcel');
		$namaFile = "waktu_absen.xls";
		$judul = "waktu_absen";
		$tablehead = 0;
		$tablebody = 1;
		$nourut = 1;
		//penulisan header
		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");
		header("Content-Disposition: attachment;filename=" . $namaFile . "");
		header("Content-Transfer-Encoding: binary ");

		xlsBOF();

		$kolomhead = 0;
		xlsWriteLabel($tablehead, $kolomhead++, "No");
		xlsWriteLabel($tablehead, $kolomhead++, "Nama Hari");
		xlsWriteLabel($tablehead, $kolomhead++, "Jam Masuk Guru");
		xlsWriteLabel($tablehead, $kolomhead++, "Absen Terlambat Guru");
		xlsWriteLabel($tablehead, $kolomhead++, "Jam Masuk Siswa");
		xlsWriteLabel($tablehead, $kolomhead++, "Absen Terlambat Siswa");
		xlsWriteLabel($tablehead, $kolomhead++, "Jam Pulang Guru");
		xlsWriteLabel($tablehead, $kolomhead++, "Jam Pulang Siswa");

		foreach ($this->Waktu_absen_model->get_all() as $data) {
			$kolombody = 0;

			//ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
			xlsWriteNumber($tablebody, $kolombody++, $nourut);
			xlsWriteLabel($tablebody, $kolombody++, $data->nama_hari);
			xlsWriteLabel($tablebody, $kolombody++, $data->jam_masuk_guru);
			xlsWriteNumber($tablebody, $kolombody++, $data->absen_terlambat_guru);
			xlsWriteLabel($tablebody, $kolombody++, $data->jam_masuk_siswa);
			xlsWriteNumber($tablebody, $kolombody++, $data->absen_terlambat_siswa);
			xlsWriteLabel($tablebody, $kolombody++, $data->jam_pulang_guru);
			xlsWriteLabel($tablebody, $kolombody++, $data->jam_pulang_siswa);

			$tablebody++;
			$nourut++;
		}

		xlsEOF();
		exit();
	}
}

/* End of file Waktu_absen.php */
/* Location: ./application/controllers/Waktu_absen.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2022-01-14 17:57:30 */
/* http://harviacode.com */
