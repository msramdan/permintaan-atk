<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Status_guru extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		is_login();
		check_admin();
		$this->load->model('Status_guru_model');
		$this->load->model('App_setting_model');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$status_guru = $this->Status_guru_model->get_all();
		$data = array(
			'status_guru_data' => $status_guru,
			'sett_apps' =>$this->App_setting_model->get_by_id(1),
		);
		$this->template->load('template', 'status_guru/status_guru_list', $data);
	}

	public function read($id)
	{
		$row = $this->Status_guru_model->get_by_id(decrypt_url($id));
		if ($row) {
			$data = array(
				'status_guru_id' => $row->status_guru_id,
				'sett_apps' =>$this->App_setting_model->get_by_id(1),
				'nama_status_guru' => $row->nama_status_guru,
			);
			$this->template->load('template', 'status_guru/status_guru_read', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('status_guru'));
		}
	}

	public function create()
	{
		$data = array(
			'button' => 'Create',
			'action' => site_url('status_guru/create_action'),
			'sett_apps' =>$this->App_setting_model->get_by_id(1),
			'status_guru_id' => set_value('status_guru_id'),
			'nama_status_guru' => set_value('nama_status_guru'),
		);
		$this->template->load('template', 'status_guru/status_guru_form', $data);
	}

	public function create_action()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->create();
		} else {
			$data = array(
				'nama_status_guru' => $this->input->post('nama_status_guru', TRUE),
			);

			$this->Status_guru_model->insert($data);
			$this->session->set_flashdata('message', 'Create Record Success');
			redirect(site_url('status_guru'));
		}
	}

	public function update($id)
	{
		$row = $this->Status_guru_model->get_by_id(decrypt_url($id));

		if ($row) {
			$data = array(
				'button' => 'Update',
				'sett_apps' =>$this->App_setting_model->get_by_id(1),
				'action' => site_url('status_guru/update_action'),
				'status_guru_id' => set_value('status_guru_id', $row->status_guru_id),
				'nama_status_guru' => set_value('nama_status_guru', $row->nama_status_guru),
			);
			$this->template->load('template', 'status_guru/status_guru_form', $data);
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('status_guru'));
		}
	}

	public function update_action()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$this->update(encrypt_url($this->input->post('status_guru_id')));
		} else {
			$data = array(
				'nama_status_guru' => $this->input->post('nama_status_guru', TRUE),
			);

			$this->Status_guru_model->update($this->input->post('status_guru_id', TRUE), $data);
			$this->session->set_flashdata('message', 'Update Record Success');
			redirect(site_url('status_guru'));
		}
	}

	public function delete($id)
	{
		$row = $this->Status_guru_model->get_by_id(decrypt_url($id));

		if ($row) {
			$this->Status_guru_model->delete(decrypt_url($id));
			$this->session->set_flashdata('message', 'Delete Record Success');
			redirect(site_url('status_guru'));
		} else {
			$this->session->set_flashdata('message', 'Record Not Found');
			redirect(site_url('status_guru'));
		}
	}

	public function _rules()
	{
		$this->form_validation->set_rules('nama_status_guru', 'nama status guru', 'trim|required');

		$this->form_validation->set_rules('status_guru_id', 'status_guru_id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
	}

	public function excel()
	{
		$this->load->helper('exportexcel');
		$namaFile = "status_guru.xls";
		$judul = "status_guru";
		$tablehead = 0;
		$tablebody = 1;
		$nourut = 1;
		//penulisan header
		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");
		header("Content-Disposition: attachment;filename=" . $namaFile . "");
		header("Content-Transfer-Encoding: binary ");

		xlsBOF();

		$kolomhead = 0;
		xlsWriteLabel($tablehead, $kolomhead++, "No");
		xlsWriteLabel($tablehead, $kolomhead++, "Nama Status Guru");

		foreach ($this->Status_guru_model->get_all() as $data) {
			$kolombody = 0;

			//ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
			xlsWriteNumber($tablebody, $kolombody++, $nourut);
			xlsWriteLabel($tablebody, $kolombody++, $data->nama_status_guru);

			$tablebody++;
			$nourut++;
		}

		xlsEOF();
		exit();
	}
}

/* End of file Status_guru.php */
/* Location: ./application/controllers/Status_guru.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2022-01-10 16:20:52 */
/* http://harviacode.com */
